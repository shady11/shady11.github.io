<?php
	$privateroom = array("Личный кабинет","Private room","Личный кабинет");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	$privateroom = array("Язык","Language","Тил");
	
?>