<?php  
require_once(ROOT_PATH."/class/mysql.class.php");
require_once(ROOT_PATH."/class/session.php");
require_once(ROOT_PATH."/class/class.upload.php");
require_once(ROOT_PATH."/class/pagenav.php");
//require_once(ROOT_PATH."/class/geoplugin.php");

//require_once(ROOT_PATH."/class/mail.class.php"); 
?>