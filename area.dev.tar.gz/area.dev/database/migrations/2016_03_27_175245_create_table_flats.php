<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableFlats extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('flats', function (Blueprint $table) {
            $table->increments('id');
            // Flat Type = ['flat','hotel','mansion','pension']
            $table->enum('flatType', ['flat', 'hotel','mansion','pension'])->nullable()->default('flat');
            $table->integer('parent')->nullable()->unsigned()->default(null);
            
            // Prices
            $table->string('priceHourKg');
            $table->string('priceHourRu');
            $table->string('priceHourEn');

            $table->string('priceNightKg');
            $table->string('priceNightRu');
            $table->string('priceNightEn');

            $table->string('price24Kg');
            $table->string('price24Ru');
            $table->string('price24En');

            $table->string('priceMonthKg');
            $table->string('priceMonthRu');
            $table->string('priceMonthEn');

            // Where
            $table->integer('district_id');
            $table->integer('city_id');
            $table->integer('region_id');

            $table->string('street');
            $table->string('crosses');
            $table->string('apartment');
            $table->string('homenumber');
            $table->string('latitude');
            $table->string('longitude');
            $table->string('zoom');

            // Contacts
            $table->string('phone');
            $table->string('phone2');
            $table->string('phone3');
            $table->string('email');
            $table->string('skype');

            // Params
            $table->string('room'); // Количество комнат
            $table->string('bed'); // Количество спальных мест
            $table->string('floor'); // Этажность 5/9
            $table->string('msquare'); // Площадь, кв.м.
            $table->string('wifi'); // wifi
            
            $table->string('name');
            $table->string('nameEn');
            $table->string('nameKg');
            $table->string('description');
            $table->string('descriptionEn');
            $table->string('descriptionKg');

            // Flags = ['mainpage','special','normal']
            $table->enum('flag', ['mainpage', 'special','normal'])->nullable()->default('normal');

            $table->string('attachment');
            $table->string('url');
            $table->boolean('published')->nullable()->default(false);

            $table->enum('status', ['new', 'published','closed','deleted'])->nullable()->default('new');
            $table->integer('owner_id')->nullable()->unsigned()->default(null);

            $table->foreign('owner_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('set null');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('flats');
    }
}
