<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableRegions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('regions', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('city_id');
            $table->integer('district_id');
            $table->string('name');
            $table->string('nameEn');
            $table->string('nameKg');
            $table->string('description');
            $table->string('descriptionEn');
            $table->string('descriptionKg');
            $table->enum('status', ['new', 'published','closed','deleted'])->nullable()->default('new');
            $table->boolean('published')->nullable()->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('regions');
    }
}
