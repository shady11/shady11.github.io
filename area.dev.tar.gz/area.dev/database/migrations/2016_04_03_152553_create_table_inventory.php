<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableInventory extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('inventory', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('order');
            $table->enum('status', ['new', 'published','closed','deleted'])->nullable()->default('new');
            $table->boolean('published')->nullable()->default(false);

            $table->string('name');
            $table->string('nameEn');
            $table->string('nameKg');
            $table->string('description');
            $table->string('descriptionEn');
            $table->string('descriptionKg');
            
            $table->string('url');
            $table->string('attachment');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('inventory');
    }
}
