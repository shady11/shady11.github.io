<?php

return [

    'driver' => 'smtp',
    'host' => 'smtp.yandex.ru',
    'port' => 465,
    'encryption' => 'ssl',
    'username' => 'ktrkkg@yandex.ru',//ваш логин
    'password' => 'slimshady11',//ваш пароль

];