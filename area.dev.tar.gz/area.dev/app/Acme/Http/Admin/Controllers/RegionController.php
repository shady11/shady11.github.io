<?php
namespace Admin\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use \Model\Region\ModelName as Region;
use \Model\District\ModelName as District;
use \Model\City\ModelName as City;

class RegionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $regions = Region::where('status','<>','deleted')->orderBy('id', 'desc')->get();
        return view('Admin::region.index', [
            'regions' => $regions,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $districts = District::where('status','<>','deleted')->lists('name', 'id')->toArray();
        return view('Admin::region.create', [
            'region'  => new Region,
            'districts' => $districts,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {        
        $region = Region::create($request->except('q'));
        return redirect()->route('admin.region.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($region)
    {
        return view('Admin::region.show', [
            'region' => $region,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Region $district)
    {
        return view('Admin::region.edit', [
            'region' => $region,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Region $region)
    {
        $region->update($request->except('q'));
        return redirect()->route('admin.region.show', $region);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    // Soft delete function
    public function softDelete(Request $request, $id)
    {
        $region = Region::where('id','=',$id)->first();
        $region->status = 'deleted';
        $region->save();
        return redirect()->route('admin.region.index');
    }
}
