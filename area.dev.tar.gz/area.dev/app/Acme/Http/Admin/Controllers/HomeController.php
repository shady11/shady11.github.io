<?php
namespace Admin\Controllers;
use \Model\Flat\ModelName as Flat;
class HomeController extends Controller {

	public function __construct()
	{
	}
	public function Home()
	{
		$flats = Flat::where('status','<>','normal')->where('status','<>','deleted')->having('flatType','=','flat')->get();
		$hotels = Flat::where('status','<>','normal')->where('parent','=',null)->where('status','<>','deleted')->having('flatType','=','hotel')->get();
		$mansions = Flat::where('status','<>','normal')->where('status','<>','deleted')->having('flatType','=','mansion')->get();
		$pensions = Flat::where('status','<>','normal')->where('parent','=',null)->where('status','<>','deleted')->having('flatType','=','pension')->get();
		return view('Admin::home', [
        	'flats' => $flats,
        	'hotels' => $hotels,
        	'mansions' => $mansions,
        	'pensions' => $pensions,
        	]);
		
	}
	public function History()
	{
		return view('Admin::layouts.history');
	}

}