<?php

namespace Admin\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Intervention\Image\ImageManagerStatic as Image;
use \Model\Mansion\ModelName as Mansion;
use \Model\District\ModelName as District;
use \Model\Inventory\ModelName as Inventory;
use \Model\FlatInventoryTie\ModelName as FlatInventoryTie;
use \Model\Gallery\ModelName as Gallery;
use \Model\Photos\ModelName as Photos;

class MansionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $mansions = Mansion::where('flatType','=','mansion')->where('status','<>','deleted')->orderBy('id', 'desc')->get();
        return view('Admin::mansion.index', [
            'mansions' => $mansions,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $districts = District::where('status','<>','deleted')->lists('name', 'id')->toArray();
        $inventories = Inventory::get();
        $inventoriesCount = Inventory::count();
        return view('Admin::mansion.create', [
            'mansion'  => new Mansion,
            'districts' => $districts,
            'inventories' => $inventories,
            'inventoriesCount' => $inventoriesCount,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $mansion = Mansion::create($request->except('q','flatType','inventories','attachment','photo1','photo2','photo3','photo4','photo5','photo6'));
        $mansion->flatType = 'mansion';
        $mansion->save();
        $inventories = $request->input('inventories');
        foreach($inventories as $inventory){
            FlatInventoryTie::create([
                'flat_id' => $mansion->id,
                'inventory_id' => $inventory,
            ]);
        }
        // Main image
        if($request->hasFile('attachment')){
            $file = $request->file('attachment');
            $dir  = 'images/mansion';
            $btw = time();
            $name = $mansion->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['attachment']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $mansion->url = $fileUrl;
            $mansion->attachment = $dir.'/'.$name;
            $mansion->save();
        }
        if($request->hasFile('attachment'))
        {
            $gallery = Gallery::create([
                'flat_id'=> $mansion->id,
                ]);
        }
        // Insert main image to Gallery
        if($request->hasFile('attachment')){
            $attachment = Photos::create([
            'flat_id'=>$mansion->id,
            'gallery_id' => $gallery->id,
            ]);        
            $file = $request->file('attachment');
            $dir  = 'images/photos';
            $btw = time();
            $name = $attachment->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['attachment']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $attachment->url = $fileUrl;
            $attachment->attachment = $dir.'/'.$name;
            $attachment->save();
        }
        // If photo1, insert to Gallery
        if($request->hasFile('photo1')){
            $photos1 = Photos::create([
            'flat_id'=>$mansion->id,
            'gallery_id' => $gallery->id,
            ]);        
            $file = $request->file('photo1');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos1->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo1']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos1->url = $fileUrl;
            $photos1->attachment = $dir.'/'.$name;
            $photos1->save();
        }
        // Create photo 2
        if($request->hasFile('photo2')){
            $photos2 = Photos::create([
            'flat_id'=>$mansion->id,
            'gallery_id' => $gallery->id,
            ]);
            $file = $request->file('photo2');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos2->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo2']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos2->url = $fileUrl;
            $photos2->attachment = $dir.'/'.$name;
            $photos2->save();
        }
        // Create photo 3
        if($request->hasFile('photo3')){
            $photos3 = Photos::create([
            'flat_id'=>$mansion->id,
            'gallery_id' => $gallery->id,
            ]);
            $file = $request->file('photo3');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos3->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo3']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos3->url = $fileUrl;
            $photos3->attachment = $dir.'/'.$name;
            $photos3->save();
        }
        // Create photo 4
        if($request->hasFile('photo4')){
            $photos4 = Photos::create([
            'flat_id'=>$mansion->id,
            'gallery_id' => $gallery->id,
            ]);
            $file = $request->file('photo4');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos4->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo4']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos4->url = $fileUrl;
            $photos4->attachment = $dir.'/'.$name;
            $photos4->save();
        }
        // Create photo 5
        if($request->hasFile('photo5')){
            $photos5 = Photos::create([
            'flat_id'=>$mansion->id,
            'gallery_id' => $gallery->id,
            ]);
            $file = $request->file('photo5');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos5->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo5']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos5->url = $fileUrl;
            $photos5->attachment = $dir.'/'.$name;
            $photos5->save();
        }
        // Create photo 6
        if($request->hasFile('photo6')){
            $photos6 = Photos::create([
            'flat_id'=>$mansion->id,
            'gallery_id' => $gallery->id,
            ]);
            $file = $request->file('photo6');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos6->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo6']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos6->url = $fileUrl;
            $photos6->attachment = $dir.'/'.$name;
            $photos6->save();
        }
        return redirect()->route('admin.mansion.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($mansion)
    {
        $mansionPhotos = Photos::where('flat_id','=',$mansion->id)->get();
        return view('Admin::mansion.show', [
            'mansion' => $mansion,
            'mansionPhotos' => $mansionPhotos,
        ]);        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Mansion $mansion)
    {
        $districts = District::where('status','<>','deleted')->lists('name', 'id')->toArray();
        $inventories = Inventory::get();
        $inventoriesCount = Inventory::count();
        $inventoryChecked = FlatInventoryTie::where('flat_id','=',$mansion->id)->get();

        return view('Admin::mansion.edit', [
            'mansion' => $mansion,
            'inventoryChecked' => $inventoryChecked,
            'districts' => $districts,
            'inventories' => $inventories,
            'inventoriesCount' => $inventoriesCount,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Mansion $mansion)
    {
        $mansion->update($request->except('q','inventories','attachment'));
        $inventories = $request->input('inventories');
        foreach($inventories as $inventory){
            $inventoryTieDelete = FlatInventoryTie::where('flat_id','=',$mansion->id)->get();
            foreach($inventoryTieDelete as $row){
                $row->delete();   
            }

            FlatInventoryTie::create([
                'flat_id' => $mansion->id,
                'inventory_id' => $inventory,
            ]);
        }
        // Main image
        if($request->hasFile('attachment')){
            $file = $request->file('attachment');
            $dir  = 'images/mansion';
            $btw = time();
            $name = $mansion->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['attachment']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $mansion->url = $fileUrl;
            $mansion->attachment = $dir.'/'.$name;
            $mansion->save();
        }
        return redirect()->route('admin.mansion.show', $mansion);
    }


    // Flat -> flag = mainpage
    public function mainpage(Request $request, $id)
    {
        $mansion = Mansion::where('id','=',$id)->first();
        $mansion->flag = 'mainpage';
        $mansion->save();
        return redirect()->route('admin.mansion.index');
    }
    // Flat -> flag = special
    public function special(Request $request, $id)
    {
        $mansion = Mansion::where('id','=',$id)->first();
        $mansion->flag = 'special';
        $mansion->save();
        return redirect()->route('admin.mansion.index');
    }
    // Flat -> flag = normal
    public function flagCancel(Request $request, $id)
    {
        $mansion = Mansion::where('id','=',$id)->first();
        $mansion->flag = 'normal';
        $mansion->save();
        return redirect()->route('admin.mansion.index');
    }


    // Soft delete function
    public function softDelete(Mansion $request, $id)
    {
        $mansion = Mansion::where('id','=',$id)->first();
        $mansion->status = 'deleted';
        $mansion->save();
        return redirect()->route('admin.mansion.index');
    }
}
