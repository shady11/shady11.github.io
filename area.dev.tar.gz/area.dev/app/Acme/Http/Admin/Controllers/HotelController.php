<?php

namespace Admin\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Intervention\Image\ImageManagerStatic as Image;
use \Model\Hotel\ModelName as Hotel;
use \Model\District\ModelName as District;
use \Model\Inventory\ModelName as Inventory;
use \Model\FlatInventoryTie\ModelName as FlatInventoryTie;
use \Model\Gallery\ModelName as Gallery;
use \Model\Photos\ModelName as Photos;

class HotelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $hotels = Hotel::where('status','<>','deleted')->where('parent','=',null)->having('flatType','=','hotel')->orderBy('id', 'desc')->get();
        $hotelNumbers = Hotel::where('parent','<>','')->get();
        return view('Admin::hotel.index', [
            'hotels' => $hotels,
            'hotelNumbers' => $hotelNumbers,
        ]);
    }   
    public function showNumber(Request $request, $hotelId)
    {
        $hotelParent = Hotel::where('id','=',$hotelId)->first();
        $hotelNumbers = Hotel::where('status','<>','deleted')->where('parent','<>','')->having('flatType','=','hotel')->orderBy('id', 'desc')->get();

        return view('Admin::hotel.showNumber', [
            'hotelNumbers' => $hotelNumbers,
            'hotelParent' => $hotelParent,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $districts = District::where('status','<>','deleted')->lists('name', 'id')->toArray();
        $inventories = Inventory::get();
        $inventoriesCount = Inventory::count();
        return view('Admin::hotel.create', [
            'hotel'  => new Hotel,
            'districts' => $districts,
            'inventories' => $inventories,
            'inventoriesCount' => $inventoriesCount,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $hotel = Hotel::create($request->except('q','flatType','inventories','attachment'));
        $hotel->flatType = 'hotel';
        $hotel->save();
        // Main image
        if($request->hasFile('attachment')){
            $file = $request->file('attachment');
            $dir  = 'images/hotel';
            $btw = time();
            $name = $hotel->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['attachment']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $hotel->url = $fileUrl;
            $hotel->attachment = $dir.'/'.$name;
            $hotel->save();
        }
        if($request->hasFile('attachment'))
        {
            $gallery = Gallery::create([
                'flat_id'=> $hotel->id,
                ]);
        }
        // Insert main image to Gallery
        if($request->hasFile('attachment')){
            $attachment = Photos::create([
            'flat_id'=>$hotel->id,
            'gallery_id' => $gallery->id,
            ]);        
            $file = $request->file('attachment');
            $dir  = 'images/photos';
            $btw = time();
            $name = $attachment->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['attachment']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $attachment->url = $fileUrl;
            $attachment->attachment = $dir.'/'.$name;
            $attachment->save();
        }
        
        return redirect()->route('admin.hotel.index');
    }

    public function numberHotel(Request $request, $id)
    {
        $hotelId = $id;
        $hotel = Hotel::where('id','=',$hotelId)->first();
        $districts = District::where('status','<>','deleted')->lists('name', 'id')->toArray();
        $inventories = Inventory::get();
        $inventoriesCount = Inventory::count();
        return view('Admin::hotel.createNumber', [
            'hotel'  => new Hotel,
            'districts' => $districts,
            'inventories' => $inventories,
            'inventoriesCount' => $inventoriesCount,
            'hotel' => $hotel,
        ]);
    }
    public function numberStore(Request $request)
    {
        $hotel = Hotel::create($request->except('q','flatType','inventories','attachment','photo1','photo2','photo3','photo4','photo5','photo6','hotelId'));
        $hotelId = $request->input('hotelId');
        $hotel->flatType = 'hotel';
        $hotel->parent = $hotelId;
        $hotel->save();
        $inventories = $request->input('inventories');
        foreach($inventories as $inventory){
            FlatInventoryTie::create([
                'flat_id' => $hotel->id,
                'inventory_id' => $inventory,
            ]);
        }
        // Main image
        if($request->hasFile('attachment')){
            $file = $request->file('attachment');
            $dir  = 'images/hotel';
            $btw = time();
            $name = $hotel->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['attachment']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $hotel->url = $fileUrl;
            $hotel->attachment = $dir.'/'.$name;
            $hotel->save();
        }
        if($request->hasFile('attachment'))
        {
            $gallery = Gallery::create([
                'flat_id'=> $hotel->id,
                ]);
        }
        // Insert main image to Gallery
        if($request->hasFile('attachment')){
            $attachment = Photos::create([
            'flat_id'=>$hotel->id,
            'gallery_id' => $gallery->id,
            ]);        
            $file = $request->file('attachment');
            $dir  = 'images/photos';
            $btw = time();
            $name = $attachment->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['attachment']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $attachment->url = $fileUrl;
            $attachment->attachment = $dir.'/'.$name;
            $attachment->save();
        }
        // If photo1, insert to Gallery
        if($request->hasFile('photo1')){
            $photos1 = Photos::create([
            'flat_id'=>$hotel->id,
            'gallery_id' => $gallery->id,
            ]);        
            $file = $request->file('photo1');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos1->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo1']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos1->url = $fileUrl;
            $photos1->attachment = $dir.'/'.$name;
            $photos1->save();
        }
        // Create photo 2
        if($request->hasFile('photo2')){
            $photos2 = Photos::create([
            'flat_id'=>$hotel->id,
            'gallery_id' => $gallery->id,
            ]);
            $file = $request->file('photo2');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos2->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo2']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos2->url = $fileUrl;
            $photos2->attachment = $dir.'/'.$name;
            $photos2->save();
        }
        // Create photo 3
        if($request->hasFile('photo3')){
            $photos3 = Photos::create([
            'flat_id'=>$hotel->id,
            'gallery_id' => $gallery->id,
            ]);
            $file = $request->file('photo3');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos3->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo3']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos3->url = $fileUrl;
            $photos3->attachment = $dir.'/'.$name;
            $photos3->save();
        }
        // Create photo 4
        if($request->hasFile('photo4')){
            $photos4 = Photos::create([
            'flat_id'=>$hotel->id,
            'gallery_id' => $gallery->id,
            ]);
            $file = $request->file('photo4');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos4->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo4']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos4->url = $fileUrl;
            $photos4->attachment = $dir.'/'.$name;
            $photos4->save();
        }
        // Create photo 5
        if($request->hasFile('photo5')){
            $photos5 = Photos::create([
            'flat_id'=>$hotel->id,
            'gallery_id' => $gallery->id,
            ]);
            $file = $request->file('photo5');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos5->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo5']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos5->url = $fileUrl;
            $photos5->attachment = $dir.'/'.$name;
            $photos5->save();
        }
        // Create photo 6
        if($request->hasFile('photo6')){
            $photos6 = Photos::create([
            'flat_id'=>$hotel->id,
            'gallery_id' => $gallery->id,
            ]);
            $file = $request->file('photo6');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos6->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo6']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos6->url = $fileUrl;
            $photos6->attachment = $dir.'/'.$name;
            $photos6->save();
        }
        return redirect()->route('admin.hotel.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showHotel(Request $request, $id)
    {
        $hotel = Hotel::where('id','=',$id)->first();
        return view('Admin::hotel.showHotel', [
            'hotel' => $hotel,
        ]);        
    }
    public function show($hotel)
    {
        $hotelPhotos = Photos::where('flat_id','=',$hotel->id)->get();
        return view('Admin::hotel.show', [
            'hotel' => $hotel,
            'hotelPhotos' => $hotelPhotos,
        ]);        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Hotel $hotel)
    {
        $districts = District::where('status','<>','deleted')->lists('name', 'id')->toArray();
        $inventories = Inventory::get();
        $inventoriesCount = Inventory::count();
        $inventoryChecked = FlatInventoryTie::where('flat_id','=',$hotel->id)->get();

        return view('Admin::hotel.edit', [
            'hotel' => $hotel,
            'inventoryChecked' => $inventoryChecked,
            'districts' => $districts,
            'inventories' => $inventories,
            'inventoriesCount' => $inventoriesCount,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Hotel $hotel)
    {
        $hotel->update($request->except('q','flatType','inventories','attachment'));
        $inventories = $request->input('inventories');
        foreach($inventories as $inventory){
            $inventoryTieDelete = FlatInventoryTie::where('flat_id','=',$hotel->id)->get();
            foreach($inventoryTieDelete as $row){
                $row->delete();   
            }

            FlatInventoryTie::create([
                'flat_id' => $hotel->id,
                'inventory_id' => $inventory,
            ]);
        }
        // Main image
        if($request->hasFile('attachment')){
            $file = $request->file('attachment');
            $dir  = 'images/hotel';
            $btw = time();
            $name = $hotel->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['attachment']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $hotel->url = $fileUrl;
            $hotel->attachment = $dir.'/'.$name;
            $hotel->save();
        }
        return redirect()->route('admin.hotel.index');
    }


    // Flat -> flag = mainpage
    public function mainpage(Request $request, $id)
    {
        $hotel = Hotel::where('id','=',$id)->first();
        $hotel->flag = 'mainpage';
        $hotel->save();
        return redirect()->route('admin.hotel.index');
    }
    // Flat -> flag = special
    public function special(Request $request, $id)
    {
        $hotel = Hotel::where('id','=',$id)->first();
        $hotel->flag = 'special';
        $hotel->save();
        return redirect()->route('admin.hotel.index');
    }
    // Flat -> flag = normal
    public function flagCancel(Request $request, $id)
    {
        $hotel = Hotel::where('id','=',$id)->first();
        $hotel->flag = 'normal';
        $hotel->save();
        return redirect()->route('admin.hotel.index');
    }


    // Soft delete function
    public function softDelete(Hotel $request, $id)
    {
        $hotel = Hotel::where('id','=',$id)->first();
        $hotel->status = 'deleted';
        $hotel->save();
        return redirect()->route('admin.hotel.index');
    }
}
