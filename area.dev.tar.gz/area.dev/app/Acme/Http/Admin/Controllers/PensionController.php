<?php
namespace Admin\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Intervention\Image\ImageManagerStatic as Image;
use \Model\Pension\ModelName as Pension;
use \Model\District\ModelName as District;
use \Model\Inventory\ModelName as Inventory;
use \Model\FlatInventoryTie\ModelName as FlatInventoryTie;
use \Model\Gallery\ModelName as Gallery;
use \Model\Photos\ModelName as Photos;
class PensionController extends Controller
{
    public function index() // Index Pensions
    {
        $pensions = Pension::where('status','<>','deleted')->where('parent','=',null)->having('flatType','=','pension')->orderBy('id', 'desc')->get();
        $pensionNumbers = Pension::where('parent','<>','')->get();
        return view('Admin::pension.index', [
            'pensions' => $pensions,
            'pensionNumbers' => $pensionNumbers,
        ]);
    }
    public function create()  // Create Pension
    {
        $districts = District::where('status','<>','deleted')->lists('name', 'id')->toArray();
        $inventories = Inventory::get();
        $inventoriesCount = Inventory::count();
        return view('Admin::pension.create', [ 
            'pension'  => new Pension,
            'districts' => $districts,
            'inventories' => $inventories,
            'inventoriesCount' => $inventoriesCount,
        ]);
    }
    // Form to create :pension.formPension.blade.php
    public function store(Request $request) // Store Pension
    {
        $pension = Pension::create($request->except('q','flatType','inventories','attachment'));
        $pension->flatType = 'pension';
        $pension->save();
        // Main image
        if($request->hasFile('attachment')){
            $file = $request->file('attachment');
            $dir  = 'images/pension';
            $btw = time();
            $name = $pension->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['attachment']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $pension->url = $fileUrl;
            $pension->attachment = $dir.'/'.$name;
            $pension->save();
        }
        if($request->hasFile('attachment'))
        {
            $gallery = Gallery::create([
                'flat_id'=> $pension->id,
                ]);
        }
        // Insert main image to Gallery
        if($request->hasFile('attachment')){
            $attachment = Photos::create([
            'flat_id'=>$pension->id,
            'gallery_id' => $gallery->id,
            ]);        
            $file = $request->file('attachment');
            $dir  = 'images/photos';
            $btw = time();
            $name = $attachment->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['attachment']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $attachment->url = $fileUrl;
            $attachment->attachment = $dir.'/'.$name;
            $attachment->save();
        }
        
        return redirect()->route('admin.pension.index');
    }

    public function showPension(Request $request, $id)
    {
        $pension = Pension::where('id','=',$id)->first();
        return view('Admin::pension.showPension', [
            'pension' => $pension,
        ]);        
    }
    public function edit(Pension $pension) // Edit Pension use form::pension.formEdit.blade.php
    {
        $districts = District::where('status','<>','deleted')->lists('name', 'id')->toArray();
        $inventories = Inventory::get();
        $inventoriesCount = Inventory::count();
        $inventoryChecked = FlatInventoryTie::where('flat_id','=',$pension->id)->get();

        return view('Admin::pension.edit', [
            'pension' => $pension,
            'inventoryChecked' => $inventoryChecked,
            'districts' => $districts,
            'inventories' => $inventories,
            'inventoriesCount' => $inventoriesCount,
        ]);
    }
    public function update(Request $request, Pension $pension) // Update Pension
    {
        $pension->update($request->except('q','flatType','inventories','attachment'));
        $inventories = $request->input('inventories');
        if(count($inventories) > 0){
            foreach($inventories as $inventory){
            $inventoryTieDelete = FlatInventoryTie::where('flat_id','=',$pension->id)->get();
            foreach($inventoryTieDelete as $row){
                $row->delete();   
            }

            FlatInventoryTie::create([
                'flat_id' => $pension->id,
                'inventory_id' => $inventory,
            ]);
        }
        }
        
        // Main image
        if($request->hasFile('attachment')){
            $file = $request->file('attachment');
            $dir  = 'images/pension';
            $btw = time();
            $name = $pension->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['attachment']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $pension->url = $fileUrl;
            $pension->attachment = $dir.'/'.$name;
            $pension->save();
        }
        return redirect()->route('admin.pension.index');
    }




    // End Pension
    // Start Pension Number



    public function indexPensionNumber(Request $request, $pensionId) // Index Pension Numbers
    {
        $pensionParent = Pension::where('id','=',$pensionId)->first();
        $pensionNumbers = Pension::where('status','<>','deleted')->where('parent','=',$pensionId)->having('flatType','=','pension')->orderBy('id', 'desc')->get();
        return view('Admin::pension.indexPensionNumber', [
            'pensionNumbers' => $pensionNumbers,
            'pensionParent' => $pensionParent,
        ]);
    }
    public function createPensionNumber(Request $request, $id)  // Create Pension Number
    {
        $pensionId = $id;
        $pension = Pension::where('id','=',$pensionId)->first();
        $districts = District::where('status','<>','deleted')->lists('name', 'id')->toArray();
        $inventories = Inventory::get();
        $inventoriesCount = Inventory::count();
        return view('Admin::pension.createPensionNumber', [
            'pension'  => new Pension,
            'districts' => $districts,
            'inventories' => $inventories,
            'inventoriesCount' => $inventoriesCount,
            'pension' => $pension,
        ]);
    }
  
    public function numberStore(Request $request) // Store Pension Number form
    {
        $pension = Pension::create($request->except('q','flatType','inventories','attachment','photo1','photo2','photo3','photo4','photo5','photo6','pensionId'));
        $pensionId = $request->input('pensionId');
        $pension->flatType = 'pension';
        $pension->parent = $pensionId;
        $pension->save();

        $inventories = $request->input('inventories');
        if(count($inventories) > 0){
            foreach($inventories as $inventory){
            FlatInventoryTie::create([
                'flat_id' => $pension->id,
                'inventory_id' => $inventory,
            ]);
            }    
        }
        
        // Main image
        if($request->hasFile('attachment')){
            $file = $request->file('attachment');
            $dir  = 'images/pension';
            $btw = time();
            $name = $pension->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['attachment']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $pension->url = $fileUrl;
            $pension->attachment = $dir.'/'.$name;
            $pension->save();
        }
        if($request->hasFile('attachment'))
        {
            $gallery = Gallery::create([
                'flat_id'=> $pension->id,
                ]);
        }
        // Insert main image to Gallery
        if($request->hasFile('attachment')){
            $attachment = Photos::create([
            'flat_id'=>$pension->id,
            'gallery_id' => $gallery->id,
            ]);        
            $file = $request->file('attachment');
            $dir  = 'images/photos';
            $btw = time();
            $name = $attachment->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['attachment']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $attachment->url = $fileUrl;
            $attachment->attachment = $dir.'/'.$name;
            $attachment->save();
        }
        // If photo1, insert to Gallery
        if($request->hasFile('photo1')){
            $photos1 = Photos::create([
            'flat_id'=>$pension->id,
            'gallery_id' => $gallery->id,
            ]);        
            $file = $request->file('photo1');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos1->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo1']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos1->url = $fileUrl;
            $photos1->attachment = $dir.'/'.$name;
            $photos1->save();
        }
        // Create photo 2
        if($request->hasFile('photo2')){
            $photos2 = Photos::create([
            'flat_id'=>$pension->id,
            'gallery_id' => $gallery->id,
            ]);
            $file = $request->file('photo2');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos2->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo2']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos2->url = $fileUrl;
            $photos2->attachment = $dir.'/'.$name;
            $photos2->save();
        }
        // Create photo 3
        if($request->hasFile('photo3')){
            $photos3 = Photos::create([
            'flat_id'=>$pension->id,
            'gallery_id' => $gallery->id,
            ]);
            $file = $request->file('photo3');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos3->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo3']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos3->url = $fileUrl;
            $photos3->attachment = $dir.'/'.$name;
            $photos3->save();
        }
        // Create photo 4
        if($request->hasFile('photo4')){
            $photos4 = Photos::create([
            'flat_id'=>$pension->id,
            'gallery_id' => $gallery->id,
            ]);
            $file = $request->file('photo4');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos4->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo4']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos4->url = $fileUrl;
            $photos4->attachment = $dir.'/'.$name;
            $photos4->save();
        }
        // Create photo 5
        if($request->hasFile('photo5')){
            $photos5 = Photos::create([
            'flat_id'=>$pension->id,
            'gallery_id' => $gallery->id,
            ]);
            $file = $request->file('photo5');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos5->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo5']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos5->url = $fileUrl;
            $photos5->attachment = $dir.'/'.$name;
            $photos5->save();
        }
        // Create photo 6
        if($request->hasFile('photo6')){
            $photos6 = Photos::create([
            'flat_id'=>$pension->id,
            'gallery_id' => $gallery->id,
            ]);
            $file = $request->file('photo6');
            $dir  = 'images/photos';
            $btw = time();
            $name = $photos6->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['photo6']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $photos6->url = $fileUrl;
            $photos6->attachment = $dir.'/'.$name;
            $photos6->save();
        }
        return redirect()->route('admin.pension.index');
    }

    public function showPensionNumber(Request $request, $id) // Show Pension Number
    {
        $pension = Pension::where('id','=',$id)->first();
        return view('Admin::pension.showPension', [
            'pension' => $pension,
        ]);        
    }
    public function editPensionNumber(Request $request, $id) // Edit Pension use form::pension.form.blade.php
    {
        $pensionNumber = Pension::where('id','=',$id)->first();
        
        $districts = District::where('status','<>','deleted')->lists('name', 'id')->toArray();
        $inventories = Inventory::get();
        $inventoriesCount = Inventory::count();
        $inventoryChecked = FlatInventoryTie::where('flat_id','=',$id)->get();

        return view('Admin::pension.editPensionNumber', [
            'pension' => $pensionNumber,
            'inventoryChecked' => $inventoryChecked,
            'districts' => $districts,
            'inventories' => $inventories,
            'inventoriesCount' => $inventoriesCount,
        ]);
    }
    public function updatePensionNumber(Request $request, $pensionId) // Update Pension Number
    {
        $pension = Pension::where('id','=',$pensionId)->first();
        $pension->update($request->except('q','flatType','pensionId','latitude','longitude','zoom','inventories','attachment'));
        $inventories = $request->input('inventories');
        if(count($inventories)>0){
            foreach($inventories as $inventory){
            $inventoryTieDelete = FlatInventoryTie::where('flat_id','=',$pension->id)->get();
                foreach($inventoryTieDelete as $row){
                    $row->delete();   
                }

            FlatInventoryTie::create([
                'flat_id' => $pension->id,
                'inventory_id' => $inventory,
            ]);
            }    
        }

        if($request->input('latitude')){
            $pension->latitude = $request->input('latitude');
            $pension->save();
        }
        if($request->input('longitude')){
            $pension->longitude = $request->input('longitude');
            $pension->save();
        }
        if($request->input('zoom')){
            $pension->zoom = $request->input('zoom');
            $pension->save();
        }
        
        // Main image
        if($request->hasFile('attachment')){
            $file = $request->file('attachment');
            $dir  = 'images/pension';
            $btw = time();
            $name = $pension->getId().$btw.'.'.$file->getClientOriginalExtension();
            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);
            Image::make($_FILES['attachment']['tmp_name'])->heighten(300)->save($dir.'/'.$name);
            $fileUrl = asset(''.$dir.'/'.$name);
            $pension->url = $fileUrl;
            $pension->attachment = $dir.'/'.$name;
            $pension->save();
        }
        return redirect()->route('admin.pension.index');
    }


    // Flat -> flag = mainpage
    public function mainpage(Request $request, $id)
    {
        $pension = Pension::where('id','=',$id)->first();
        $pension->flag = 'mainpage';
        $pension->save();
        return redirect()->route('admin.pension.index');
    }
    // Flat -> flag = special
    public function special(Request $request, $id)
    {
        $pension = Pension::where('id','=',$id)->first();
        $pension->flag = 'special';
        $pension->save();
        return redirect()->route('admin.pension.index');
    }
    // Flat -> flag = normal
    public function flagCancel(Request $request, $id)
    {
        $pension = Pension::where('id','=',$id)->first();
        $pension->flag = 'normal';
        $pension->save();
        return redirect()->route('admin.pension.index');
    }




    // Soft delete function
    public function softDelete(Pension $request, $id)
    {
        $pension = Pension::where('id','=',$id)->first();
        $pension->status = 'deleted';
        $pension->save();
        return redirect()->route('admin.pension.index');
    }

    /*public function show($pension) // Show Pension
    {
        $pensionPhotos = Photos::where('flat_id','=',$pension->id)->get();
        return view('Admin::pension.show', [
            'pension' => $pension,
            'pensionPhotos' => $pensionPhotos,
        ]);        
    }*/
}
