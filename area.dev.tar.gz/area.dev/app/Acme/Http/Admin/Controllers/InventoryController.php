<?php
namespace Admin\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Intervention\Image\ImageManagerStatic as Image;
use \Model\Inventory\ModelName as Inventory;

class InventoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $inventories = Inventory::where('status','<>','deleted')->orderBy('id', 'desc')->get();
        return view('Admin::inventory.index', [
            'inventories' => $inventories,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('Admin::inventory.create', [
            'inventory'  => new Inventory,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $inventory = Inventory::create($request->except('q','attachment'));

        if($request->hasFile('attachment')){
            $file = $request->file('attachment');
            $dir  = 'images/inventories';
            $btw = time();

            $name = $inventory->getId().$btw.'.'.$file->getClientOriginalExtension();

            $storage = \Storage::disk('public');
            $storage->makeDirectory($dir);

            Image::make($_FILES['attachment']['tmp_name'])->heighten(300)->save($dir.'/'.$name);

            $fileUrl = asset(''.$dir.'/'.$name);
            $inventory->url = $fileUrl;
            $inventory->attachment = $dir.'/'.$name;
            

            $inventory->save();
        }

        return redirect()->route('admin.inventory.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($inventory)
    {
        return view('Admin::inventory.show', [
            'inventory' => $district,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Inventory $inventory)
    {
        return view('Admin::inventory.edit', [
            'inventory' => $inventory,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Inventory $inventory)
    {
        $inventory->update($request->except('q'));
        return redirect()->route('admin.inventory.show', $inventory);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    // Soft delete function
    public function softDelete(Request $request, $id)
    {
        $inventory = Inventory::where('id','=',$id)->first();
        $inventory->delete();
        return redirect()->route('admin.inventory.index');
    }
}
