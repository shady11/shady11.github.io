<?php

Route::group(['prefix' => 'admin', 'middleware' => 'access:admin', 'namespace' => 'Admin\Controllers'], function(){
    Route::get('/',     ['as' => 'admin.home', 'uses' => 'HomeController@Home']);

//	Flat routes
//	District routes
    Route::get('district/softDelete/{id}',['as' => 'admin.district.softDelete', 'uses' => 'DistrictController@softDelete']);

//	City routes
    Route::get('city/softDelete/{id}',['as' => 'admin.city.softDelete', 'uses' => 'CityController@softDelete']);

//	Region routes
    Route::get('region/softDelete/{id}',['as' => 'admin.region.softDelete', 'uses' => 'RegionController@softDelete']);

//  Flat routes 
    Route::get('flat/softDelete/{id}',['as' => 'admin.flat.softDelete', 'uses' => 'FlatController@softDelete']);    
    

    // flag mainpage - Flat
    Route::get('flat/mainpage/{id}',['as' => 'admin.flat.mainpage', 'uses' => 'FlatController@mainpage']);
    // flag special - Flat
    Route::get('flat/special/{id}',['as' => 'admin.flat.special', 'uses' => 'FlatController@special']);    
    // flagCancel - Flat
    Route::get('flat/flagCancel/{id}',['as' => 'admin.flat.flagCancel', 'uses' => 'FlatController@flagCancel']);    

    
    // flag mainpage - Hotel
    Route::get('hotel/mainpage/{id}',['as' => 'admin.hotel.mainpage', 'uses' => 'HotelController@mainpage']);
    // flag special - Hotel
    Route::get('hotel/special/{id}',['as' => 'admin.hotel.special', 'uses' => 'HotelController@special']);    
    // flagCancel - Hotel
    Route::get('hotel/flagCancel/{id}',['as' => 'admin.hotel.flagCancel', 'uses' => 'HotelController@flagCancel']); 


    // flag mainpage - Mansion
    Route::get('mansion/mainpage/{id}',['as' => 'admin.mansion.mainpage', 'uses' => 'MansionController@mainpage']);
    // flag special - Mansion
    Route::get('mansion/special/{id}',['as' => 'admin.mansion.special', 'uses' => 'MansionController@special']);    
    // flagCancel - Mansion
    Route::get('mansion/flagCancel/{id}',['as' => 'admin.mansion.flagCancel', 'uses' => 'MansionController@flagCancel']);    
    

     // flag mainpage - Pension
    Route::get('pension/mainpage/{id}',['as' => 'admin.pension.mainpage', 'uses' => 'PensionController@mainpage']);
    // flag special - Pension
    Route::get('pension/special/{id}',['as' => 'admin.pension.special', 'uses' => 'PensionController@special']);    
    // flagCancel - Pension
    Route::get('pension/flagCancel/{id}',['as' => 'admin.pension.flagCancel', 'uses' => 'PensionController@flagCancel']);    


//  Mansion routes
    Route::get('mansion/softDelete/{id}',['as' => 'admin.mansion.softDelete', 'uses' => 'MansionController@softDelete']);    

//  Hotel routes
    Route::get('hotel/softDelete/{id}',['as' => 'admin.hotel.softDelete', 'uses' => 'HotelController@softDelete']);    
    Route::get('hotel/showHotel/{id}',['as' => 'admin.hotel.showHotel', 'uses' => 'HotelController@showHotel']);    
    Route::get('hotel/numberHotel/{id}',['as' => 'admin.hotel.numberHotel', 'uses' => 'HotelController@numberHotel']);    
    Route::post('hotel/numberStore',['as' => 'admin.hotel.numberStore', 'uses' => 'HotelController@numberStore']);    
    Route::get('hotel/indexHotelNumber/{hotelId}',['as' => 'admin.hotel.indexHotelNumber', 'uses' => 'HotelController@indexHotelNumber']);    

//  Show hotel number
    Route::get('hotel/showNumber/{pensionId}',['as' => 'admin.hotel.showNumber', 'uses' => 'HotelController@showNumber']);

//  Pension routes
    Route::get('pension/createPensionNumber/{id}',['as' => 'admin.pension.createPensionNumber', 'uses' => 'PensionController@createPensionNumber']);
    Route::get('pension/showPension/{id}',['as' => 'admin.pension.showPension', 'uses' => 'PensionController@showPension']);    
    Route::get('pension/indexPensionNumber/{hotelId}',['as' => 'admin.pension.indexPensionNumber', 'uses' => 'PensionController@indexPensionNumber']);    
    // Create Pension Number
    Route::get('pension/createPensionNumber/{id}',['as' => 'admin.pension.createPensionNumber', 'uses' => 'PensionController@createPensionNumber']);
    // Pension Update Number
    Route::post('pension/updatePensionNumber/{pensionId}',['as' => 'admin.pension.updatePensionNumber', 'uses' => 'PensionController@updatePensionNumber']);    

    Route::get('pension/softDelete/{id}',['as' => 'admin.pension.softDelete', 'uses' => 'PensionController@softDelete']);    
    
    Route::post('pension/numberStore',['as' => 'admin.pension.numberStore', 'uses' => 'PensionController@numberStore']);    
    Route::get('pension/showNumber/{pensionId}',['as' => 'admin.pension.showNumber', 'uses' => 'PensionController@showNumber']);
    Route::get('pension/editPensionNumber/{id}',['as' => 'admin.pension.editPensionNumber', 'uses' => 'PensionController@editPensionNumber']);
    

//  Inventory routes
    Route::get('inventory/softDelete/{id}',['as' => 'admin.inventory.softDelete', 'uses' => 'InventoryController@softDelete']);    

//  Ajax routes
    Route::post('loadCities', ['as'=>'admin.loadCities', 'uses'=>'AjaxController@loadCities']);
    Route::post('loadRegions', ['as'=>'admin.loadRegions', 'uses'=>'AjaxController@loadRegions']);

//	Resource routes
    Route::resource('user', 'UserController');
    Route::resource('flat', 'FlatController'); // flat - квартира
    Route::resource('mansion', 'MansionController'); // mansion - особняк
    Route::resource('hotel', 'HotelController'); // hotel - отель
    Route::resource('pension', 'PensionController'); // pension - пансионат
    Route::resource('region', 'RegionController');
    Route::resource('city', 'CityController');    
    Route::resource('district', 'DistrictController');
    Route::resource('inventory', 'InventoryController');
    Route::resource('flatInventoryTie', 'FlatInventoryTieController');
    
});
