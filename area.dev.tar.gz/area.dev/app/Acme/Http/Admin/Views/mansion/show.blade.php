@extends('Admin::layouts.default')
@section('title', $mansion->getName())

@section('content')

    @include('Admin::mansion.nav')

    <div class="content">
        <div class="container-fluid">

            <div class="row">

                <div class="col-md-12">
                    <div class="card card-info">
                        <div class="header">
                            <h4 class="title">
                                {{ $mansion->getName() }}
                            </h4>
                        </div>

                        <div class="content">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <tbody>
                                                <tr>
                                                    <td class="heading">
                                                        Название
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getName() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Название на Английском
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getNameEn() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Название на Кыргызском
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getNameKg() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Описание
                                                    </td>
                                                    <td>
                                                    <textarea disabled="" class="form-control" rows="5">{{ $mansion->getDescription() }}</textarea>
                                                        
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Описание на Английском
                                                    </td>
                                                    <td>
                                                        <textarea disabled="" class="form-control" rows="5">{{ $mansion->getDescriptionEn() }}</textarea>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Описание на Кыргызском
                                                    </td>
                                                    <td>
                                                    <textarea disabled="" class="form-control" rows="5">{{ $mansion->getDescriptionKg() }}</textarea>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Цена за час
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getPriceHourKg() }}
                                                        {{ $mansion->getPriceHourRu() }}
                                                        {{ $mansion->getPriceHourEn() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Цена за ночь
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getPriceNightKg() }}
                                                        {{ $mansion->getPriceNightRu() }}
                                                        {{ $mansion->getPriceNightEn() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Цена за Сутки
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getPrice24Kg() }}
                                                        {{ $mansion->getPrice24Ru() }}
                                                        {{ $mansion->getPrice24En() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Цена за Месяц
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getPriceMonthKg() }}
                                                        {{ $mansion->getPriceMonthRu() }}
                                                        {{ $mansion->getPriceMonthEn() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Область
                                                    </td>
                                                    <td>
                                                        @if($mansion->districtRelation()->first())
                                                        {{ $mansion->districtRelation()->first()->getName() }}
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Город
                                                    </td>
                                                    <td>
                                                        @if($mansion->cityRelation()->first())
                                                        {{ $mansion->cityRelation()->first()->getName() }}
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Район
                                                    </td>
                                                    <td>
                                                        @if($mansion->regionRelation()->first())
                                                        {{ $mansion->regionRelation()->first()->getName() }}
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Улица
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getStreet() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Пересекается
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getCrosses() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Номер дома
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getApartment() }}
                                                    </td>
                                                </tr> 
                                                <tr>
                                                    <td class="heading">
                                                        Номер квартиры
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getHomenumber() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        На карте
                                                    </td>
                                                    <td>
                                                    <div class="row"> <!-- Map -->
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <div id="map_canvas" style="width:650px; margin: 20px; height:460px; border:solid 1px #FF0000" ></div>
                                                                <input name="latitude" id="latitude" type="hidden">
                                                                <input name="longitude" id="longitude" type="hidden">
                                                                <input name="zoom" id="zoom" type="hidden">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td class="heading">
                                                        Телефоны
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getPhone() }} ,
                                                        {{ $mansion->getPhone2() }} ,
                                                        {{ $mansion->getPhone3() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Email
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getEmail() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Skype
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getSkype() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Количество комнат
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getRoom() }}
                                                    </td>
                                                </tr>
                                                 <tr>
                                                    <td class="heading">
                                                        Количество спальных мест
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getBed() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Этажность
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getFloor() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Площадь
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getMsquare() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Wifi
                                                    </td>
                                                    <td>
                                                        {{ $mansion->getWifi() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Главное фото
                                                    </td>
                                                    <td>
                                                        <img src="{{ asset($mansion->getAttachment()) }}" width="460">
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td class="heading">
                                                        Все картинки
                                                    </td>
                                                    <td>
                                                        @foreach($mansionPhotos as $row)
                                                            <img src="{{ asset($row->getFile()) }}" width="250">
                                                        @endforeach
                                                    </td>
                                                </tr>
                                                
                                            </tbody>
                                        </table>
                                    </div>


                                    
                                    <div class="actions">
                                        <a href="{{ route('admin.mansion.edit', $mansion)}}" class="btn btn-primary">
                                            Редактировать
                                        </a>
                                        <a href="#" onclick="history.go(-1);" class="btn btn-default">Назад</a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')
<script type="text/javascript"
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAkDCwNRQqDIE_kz7uBfmNl1iOBsCT2nt8&sensor=true">
    </script>
    <script type="text/javascript">
      function initialize() {
        var mapOptions = {
          zoom: {{ $mansion->getZoom()}},
          center: new google.maps.LatLng({{ $mansion->getLatitude()}},{{ $mansion->getLongitude()}}),
          mapTypeId: google.maps.MapTypeId.ROADMAP
        }
        var map = new google.maps.Map(document.getElementById('map_canvas'),mapOptions);
        geocoder = new google.maps.Geocoder();

        var image = 'images/beachflag.png';
        var myLatLng = new google.maps.LatLng({{ $mansion->getLatitude()}},{{ $mansion->getLongitude()}});
        
        
        var marker = new google.maps.Marker({
            position: myLatLng, 
            map: map, 
            title: "{{ $mansion->getStreet()}} {{ $mansion->getApartment()}}"
        });  
      }
      
    </script>
@stop