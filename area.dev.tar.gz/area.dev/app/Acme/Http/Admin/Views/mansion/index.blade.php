@extends('Admin::layouts.default')
@section('title', "Особняк")

@section('content')
@include('Admin::mansion.nav')
<div class="content">
    <div class="container-fluid">

        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">
                            Особняки
                        </h4>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover">
                            <thead>
                                <th>ID</th>
                                <th>Название</th>
                                <th>Действия</th>
                            </thead>
                            <tbody>
                                @foreach($mansions as $mansion)
                                    <tr class="success">
                                        <td>{{ $mansion->getId() }}</td>
                                        <td>
                                            <a href="{{ route('admin.mansion.show', $mansion) }}">
                                                {{ $mansion->getName() }}
                                            </a>
                                        </td>

                                        <td>
                                            <ul>
                                                <li>
                                                    <a rel="tooltip" class="view" href="{{ route('admin.mansion.show', $mansion) }}" title="Посмотреть">
                                                        <i class="pe-7s-next-2"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="edit" href="{{ route('admin.mansion.edit', $mansion) }}" title="Редактировать">
                                                        <i class="pe-7s-pen"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="delete" href="{{ route('admin.mansion.softDelete', $mansion) }}" title="Удалить">
                                                        <i class="pe-7s-trash"></i>
                                                    </a>
                                                </li>

                                                @if($mansion->flag == 'mainpage')
                                                <li>
                                                    <a rel="tooltip" href="{{ route('admin.mansion.flagCancel', $mansion->id) }}" title="Отменить">
                                                        <i class="pe-7s-flag"></i>
                                                    </a>
                                                </li>
                                                @else
                                                <li>
                                                    <a rel="tooltip" class="edit" href="{{ route('admin.mansion.mainpage', $mansion->id) }}" title="Главная">
                                                        <i class="pe-7s-flag"></i>
                                                    </a>
                                                </li>
                                                @endif

                                                @if($mansion->flag == 'special')
                                                <li>
                                                    <a rel="tooltip" href="{{ route('admin.mansion.flagCancel', $mansion->id) }}" title="Отменить">
                                                        <i class="pe-7s-diamond"></i>
                                                    </a>
                                                </li>
                                                @else
                                                <li>
                                                <a rel="tooltip" class="delete" href="{{ route('admin.mansion.special', $mansion->id) }}" title="Специальное">
                                                    <i class="pe-7s-diamond"></i>
                                                </a>
                                                </li>
                                                @endif
                                            </ul>
                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection