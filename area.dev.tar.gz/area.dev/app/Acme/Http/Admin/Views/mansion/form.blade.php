<div class="row">
    <h4 style="margin:10px;">Расценки</h4>
    <div class="col-md-3">
        <div class="form-group">
            <label for="priceHour">Цена на час</label>
            {!! Form::text('priceHourKg', null, ["class" => "form-control", "required" => true, "placeholder" => "Пример: 500 сом"]) !!} <br />
            {!! Form::text('priceHourRu', null, ["class" => "form-control", "placeholder" => "Пример: 500 рублей"]) !!}<br />
            {!! Form::text('priceHourEn', null, ["class" => "form-control", "placeholder" => "Пример: 10 $"]) !!}
        </div>        
    </div>

    <div class="col-md-3">
        <div class="form-group">
            <label for="priceHour">Цена на ночь</label>
            {!! Form::text('priceNightKg', null, ["class" => "form-control", "required" => true, "placeholder" => "Пример: 800 сом"]) !!} <br />
            {!! Form::text('priceNightRu', null, ["class" => "form-control", "placeholder" => "Пример: 800 рублей"]) !!}<br />
            {!! Form::text('priceNightEn', null, ["class" => "form-control", "placeholder" => "Пример: 15 $"]) !!}
        </div>        
    </div>

    <div class="col-md-3">
        <div class="form-group">
            <label for="priceHour">Цена на сутки</label>
            {!! Form::text('price24Kg', null, ["class" => "form-control", "placeholder" => "Пример: 1200 сом"]) !!} <br />
            {!! Form::text('price24Ru', null, ["class" => "form-control", "placeholder" => "Пример: 1200 рублей"]) !!}<br />
            {!! Form::text('price24En', null, ["class" => "form-control", "placeholder" => "Пример: 25 $"]) !!}
        </div>        
    </div>

    <div class="col-md-3">
        <div class="form-group">
            <label for="priceHour">Цена на месяц</label>
            {!! Form::text('priceMonthKg', null, ["class" => "form-control", "placeholder" => "Пример: 10000 сом"]) !!} <br />
            {!! Form::text('priceMonthRu', null, ["class" => "form-control", "placeholder" => "Пример: 10000 рублей"]) !!}<br />
            {!! Form::text('priceMonthEn', null, ["class" => "form-control", "placeholder" => "Пример: 110 $"]) !!}
        </div>        
    </div>
</div>

<div class="row">
    <h4 style="margin: 10px;">Местонахождение</h4>
    <div class="col-md-3">
        <div class="form-group">
            <label for="district_id">Области</label>
            {!! Form::select('district_id', $districts, null, ["onchange"=>"loadCities($('#district_id'), $('#city_id'))","class" => "form-control selectpicker","id"=>"district_id", "title" => "-- Выберите --"]) !!}
        </div>
    </div>

    <div class="col-md-3">
        <div class="form-group">
            <label for="cities_id">Города</label>
            <select name="city_id" class="form-control selectpicker" onchange="loadRegions($('#city_id'),$('#region_id'))" title="-- Выберите --" id="city_id">
                
            </select>
        </div>
    </div>

    <div class="col-md-3">
        <div class="form-group">
            <label for="region_id">Район</label>
            <select name="region_id" class="form-control selectpicker" title="-- Выберите --" id="region_id">
                
            </select>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label for="name">Улица</label>
            {!! Form::text('street', null, ["class" => "form-control", "placeholder" => "Токтогула"]) !!}
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label for="name">Пересекается</label>
            {!! Form::text('crosses', null, ["class" => "form-control", "placeholder" => "Ибраимова"]) !!}
        </div>
    </div>

    <div class="col-md-3">
        <div class="form-group">
            <label for="name">Номер дома</label>
            {!! Form::text('apartment', null, ["class" => "form-control", "placeholder" => "15"]) !!}
        </div>
    </div>

    <div class="col-md-3">
        <div class="form-group">
            <label for="name">Номер квартиры</label>
            {!! Form::text('homenumber', null, ["class" => "form-control", "placeholder" => "5"]) !!}
        </div>
    </div>
</div>

<div class="row"> <!-- Map -->
    <div class="col-md-6">
        <div class="form-group">
        <label for="name">Вы должны указать флажок где находиться ваш объект</label>
            <div id="map_canvas" style="width:750px; margin: 20px; height:560px; border:solid 1px #FF0000" ></div>
            <input name="latitude" id="latitude" type="hidden">
            <input name="longitude" id="longitude" type="hidden">
            <input name="zoom" id="zoom" type="hidden">
        </div>
    </div>
</div>


<div class="row">
    <h4 style="margin: 10px;">Контактная информация</h4>
    <div class="col-md-3">
        <div class="form-group">
            <label for="phone">Номер телефона</label>
            {!! Form::text('phone', null, ["class" => "form-control", "required" => true, "placeholder" => "+996 555 123 456"]) !!}
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label for="phone2">Доп. номер телефона</label>
            {!! Form::text('phone2', null, ["class" => "form-control", "placeholder" => "+996 700 123 456"]) !!}
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label for="phone3">Доп. номер телефона</label>
            {!! Form::text('phone3', null, ["class" => "form-control", "placeholder" => "+996 770 123 456"]) !!}
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label for="email">Email</label>
            {!! Form::text('email', null, ["class" => "form-control", "placeholder" => "example@example.kg"]) !!}
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label for="skype">Skype</label>
            {!! Form::text('skype', null, ["class" => "form-control", "placeholder" => "skype"]) !!}
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="name">Название на русском</label>
            {!! Form::text('name', null, ["class" => "form-control", "required" => true, "placeholder" => "Название на русском"]) !!}
        </div>
    </div>
    <div class="col-md-12">
        <div class="form-group">
            <label>Описание на русском</label>
            {!! Form::textarea('description', null, ["class" => "form-control", "rows"=>5, "placeholder" => "Описание на русском"]) !!}
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="nameEn">Название на английском (необязательно)</label>
            {!! Form::text('nameEn', null, ["class" => "form-control", "placeholder" => "Название на английском"]) !!}
        </div>
    </div>

    <div class="col-md-12">
        <div class="form-group">
            <label>Описание на английском</label>
{!! Form::textarea('descriptionEn', null, ["class" => "form-control", "rows"=>5, "placeholder" => "Описание на английском"]) !!}
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="nameKg">Название на кыргызском (необязательно)</label>
            {!! Form::text('nameKg', null, ["class" => "form-control", "placeholder" => "Название на кыргызском"]) !!}
        </div>
    </div>
    <div class="col-md-12">
        <div class="form-group">
            <label>Описание на кыргызском</label>
{!! Form::textarea('descriptionEn', null, ["class" => "form-control", "rows"=>5, "placeholder" => "Описание на кыргызском"]) !!}
        </div>
    </div>
</div>

<div class="row">
    <h4 style="margin: 10px;">Параметры объекта</h4>

    <div class="col-md-2">
        <div class="form-group">
            <label for="room">Количество комнат</label>
            {!! Form::text('room', null, ["class" => "form-control", "placeholder" => "1"]) !!}
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label for="room">Количество спальных мест</label>
            {!! Form::text('bed', null, ["class" => "form-control", "placeholder" => "2"]) !!}
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label for="room">Этажность</label>
            {!! Form::text('floor', null, ["class" => "form-control", "placeholder" => "5/9"]) !!}
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label for="room">Площадь, кв.м.</label>
            {!! Form::text('msquare', null, ["class" => "form-control", "placeholder" => "52 кв.м"]) !!}
        </div>
    </div>

    <div class="col-md-2">
        <div class="form-group">
            <label for="flag">WiFi</label>
            {!! Form::hidden('wifi', 0) !!}
            {!! Form::checkbox('wifi', 1, null, ["id" => "flag", "class" => "form-control styled", "style" => "width: 34px; margin: 0"]) !!}  
        </div>        
    </div>
</div>

<div class="row">
    <h4 style="margin: 10px;">Инвентарь: (обязательно)</h4> <br />
    <div class="form-group" style="margin:10px;">
        @foreach($inventories as $inventory)
            <div style="width:350px;float:left">
                <input type="checkbox" value="{{ $inventory->id }}"
                @for ($i=0; $i<$inventoriesCount; $i++) 
                    @if ($inventory[$i]==$inventory->id)
                        "checked="checked"
                    @endif
                @endfor
                name="inventories[]"/> {{ $inventory["name"] }}
            </div>
        @endforeach
        
    </div>
</div>

<div class="row">
    <h4 style="margin: 10px;">Фото</h4>
    <div class="form-group col-md-3">
        <label for="attachment">Главное фото</label>
        <div class="fileinput fileinput-new input-group" data-provides="fileinput">
            <div class="form-control" data-trigger="fileinput">
                <i class="glyphicon glyphicon-file fileinput-exists"></i>
                <span class="fileinput-filename"></span>
            </div>
        <span class="input-group-addon btn btn-default btn-file">
                    <span class="fileinput-new">Выберите файл</span>
        <span class="fileinput-exists">Изменить</span>
        <input id="attachment" type="file" name="attachment">
        </span>
            <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Удалить</a>
        </div>
        <p class="help-block">Минимальное разрешение фотографии должно составлять 720 (ширина) на 477 (высота) пикселей</p>
    </div>
</div>


<div class="row">
    <div class="form-group col-md-3">
        <label for="photo1">Дополнительное фото 1</label>
        <div class="fileinput fileinput-new input-group" data-provides="fileinput">
            <div class="form-control" data-trigger="fileinput">
                <i class="glyphicon glyphicon-file fileinput-exists"></i>
                <span class="fileinput-filename"></span>
            </div>
        <span class="input-group-addon btn btn-default btn-file">
                    <span class="fileinput-new">Выберите файл</span>
        <span class="fileinput-exists">Изменить</span>
        <input id="photo1" type="file" name="photo1">
        </span>
            <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Удалить</a>
        </div>
    </div>
</div>

<div class="row">
    <div class="form-group col-md-3">
        <label for="photo2">Дополнительное фото 2</label>
        <div class="fileinput fileinput-new input-group" data-provides="fileinput">
            <div class="form-control" data-trigger="fileinput">
                <i class="glyphicon glyphicon-file fileinput-exists"></i>
                <span class="fileinput-filename"></span>
            </div>
        <span class="input-group-addon btn btn-default btn-file">
                    <span class="fileinput-new">Выберите файл</span>
        <span class="fileinput-exists">Изменить</span>
        <input id="photo2" type="file" name="photo2">
        </span>
            <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Удалить</a>
        </div>
    </div>
</div>


<div class="row">
    <div class="form-group col-md-3">
        <label for="photo3">Дополнительное фото 3</label>
        <div class="fileinput fileinput-new input-group" data-provides="fileinput">
            <div class="form-control" data-trigger="fileinput">
                <i class="glyphicon glyphicon-file fileinput-exists"></i>
                <span class="fileinput-filename"></span>
            </div>
        <span class="input-group-addon btn btn-default btn-file">
                    <span class="fileinput-new">Выберите файл</span>
        <span class="fileinput-exists">Изменить</span>
        <input id="photo3" type="file" name="photo3">
        </span>
            <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Удалить</a>
        </div>
    </div>
</div>

<div class="row">
    <div class="form-group col-md-3">
        <label for="photo4">Дополнительное фото 4</label>
        <div class="fileinput fileinput-new input-group" data-provides="fileinput">
            <div class="form-control" data-trigger="fileinput">
                <i class="glyphicon glyphicon-file fileinput-exists"></i>
                <span class="fileinput-filename"></span>
            </div>
        <span class="input-group-addon btn btn-default btn-file">
                    <span class="fileinput-new">Выберите файл</span>
        <span class="fileinput-exists">Изменить</span>
        <input id="photo4" type="file" name="photo4">
        </span>
            <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Удалить</a>
        </div>
    </div>
</div>

<div class="row">
    <div class="form-group col-md-3">
        <label for="photo5">Дополнительное фото 5</label>
        <div class="fileinput fileinput-new input-group" data-provides="fileinput">
            <div class="form-control" data-trigger="fileinput">
                <i class="glyphicon glyphicon-file fileinput-exists"></i>
                <span class="fileinput-filename"></span>
            </div>
        <span class="input-group-addon btn btn-default btn-file">
                    <span class="fileinput-new">Выберите файл</span>
        <span class="fileinput-exists">Изменить</span>
        <input id="photo5" type="file" name="photo5">
        </span>
            <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Удалить</a>
        </div>
    </div>
</div>

<div class="row">
    <div class="form-group col-md-3">
        <label for="photo6">Дополнительное фото 6</label>
        <div class="fileinput fileinput-new input-group" data-provides="fileinput">
            <div class="form-control" data-trigger="fileinput">
                <i class="glyphicon glyphicon-file fileinput-exists"></i>
                <span class="fileinput-filename"></span>
            </div>
        <span class="input-group-addon btn btn-default btn-file">
                    <span class="fileinput-new">Выберите файл</span>
        <span class="fileinput-exists">Изменить</span>
        <input id="photo6" type="file" name="photo6">
        </span>
            <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Удалить</a>
        </div>
    </div>
</div>


<div class="action">
    <button type="submit" class="btn btn-primary">Сохранить</button>
    <button onclick="history.go(-1);" class="btn btn-default">Назад</button>
</div>