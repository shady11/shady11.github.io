@extends('Admin::layouts.default')
@section('title', "Редактирование")

@section('styles')
    <meta name="_token" content="{!! csrf_token() !!}"/>
    <link rel="stylesheet" type="text/css" href="{{ asset('css/jasny-bootstrap.css') }}" />
@stop

@section('content')
    <!-- include subcategory nav -->
    @include('Admin::mansion.nav')
    <!-- end subcategory nav -->

    <div class="content">
        <div class="container-fluid">

            <div class="row">

                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h4 class="title">Редактировать</h4>
                        </div>
                        <div class="content">
                            {!! Form::model($mansion, ['route' => ['admin.mansion.update', $mansion], 'method' => 'PUT','enctype' => 'multipart/form-data']) !!}
                            @include('Admin::mansion.formEdit', [$mansion])
                            {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')
    <script type="text/javascript" src="{{ asset('js/admin/moment.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/admin/transition.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/admin/collapse.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/admin/ru.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/admin/bootstrap-datetimepicker.js') }}"></script>

    <script type="text/javascript"
          src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAkDCwNRQqDIE_kz7uBfmNl1iOBsCT2nt8&sensor=true">
    </script>
    <script>
          
        function initialize() 
        {
            mapOptions = {
              zoom: {{ $mansion->getZoom() }},
              center: new google.maps.LatLng({{ $mansion->getLatitude() }},{{ $mansion->getLongitude() }}),
              mapTypeId: google.maps.MapTypeId.ROADMAP
            }
            map = new google.maps.Map(document.getElementById('map_canvas'),mapOptions);
            geocoder = new google.maps.Geocoder();
    
            //var image = 'images/beachflag.png';
            var myLatLng = new google.maps.LatLng({{ $mansion->getLatitude() }},{{ $mansion->getLongitude() }});

            marker = new google.maps.Marker({
                position: myLatLng, 
                map: map, 
                title: "Ваш объект?"
            });
            
            google.maps.event.addListener(map, 'center_changed', function() {
                marker.setPosition(map.getCenter());
                document.getElementById("latitude").value = map.getCenter().lat(); 
                document.getElementById("longitude").value = map.getCenter().lng(); 
                document.getElementById("zoom").value = map.getZoom(); 
            });
            
            google.maps.event.addListener(map, "zoom_changed", function(){ 
              document.getElementById("zoom").value = map.getZoom(); 
            }); 
              
        }


        function loadCities(source, target) {
            var id = source.val();
            var dataString = 'id=' + id;
            var url = "{{ route('admin.loadCities') }}";

            $.ajaxSetup({
                headers: {'X-CSRF-Token': $('meta[name=_token]').attr('content')}
            });

            $.ajax
            ({
                type: "POST",
                url: url,
                data: dataString,
                cache: false,
                success: function (data) {
                    target.html(data);
                    $('.selectpicker').selectpicker('refresh');
                }
            });
        }  

        function loadRegions(source, target) {
            var id = source.val();
            var dataString = 'id=' + id;
            var url = "{{ route('admin.loadRegions') }}";

            $.ajaxSetup({
                headers: {'X-CSRF-Token': $('meta[name=_token]').attr('content')}
            });

            $.ajax
            ({
                type: "POST",
                url: url,
                data: dataString,
                cache: false,
                success: function (data) {
                    target.html(data);
                    $('.selectpicker').selectpicker('refresh');
                }
            });
        }  
    
    </script>
    
@stop