@extends('Admin::layouts.default')
@section('title', "Admin panel")

@section('content')

<nav class="navbar navbar-default navbar-fixed">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse">
            {{--<ul class="nav navbar-nav navbar-left">--}}
            {{--<li>--}}
            {{--<a href="{{ route('admin.order.create') }}" class="btn btn-success btn-block">--}}
            {{--Добавить заказ--}}
            {{--<i class="pe-7s-note2"></i>--}}
            {{--</a>--}}
            {{--</li>--}}
            {{--</ul>--}}
            <ul class="nav navbar-nav navbar-right">

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        {{ auth()->user()->getName() }}
                        <b class="caret"></b>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a href="#">Личный кабинет</a></li>

                        <li class="divider"></li>
                        <li><a href="javascript:document.getElementById('logout-form').submit()">Выйти</a></li>
                    </ul>
                </li>

            </ul>
        </div>
    </div>
</nav>

<div class="content">
    <div class="container-fluid">

        <div class="row">

            <div class="col-md-12">
                <div class="card ">
                    <div class="header">
                        <h4 class="title">Объекты отмеченные "Главная" или "Спец предложения"</h4>
                    </div>
                    <div class="content">
                        <div class="table-full-width">
                            <table class="table">
                                <tbody>
                                <tr>
                                    <td class="heading">
                                        <h3>Квартиры</h3>
                                    </td>
                                    <td></td>
                                </tr>
                                @foreach($flats as $row)
                                <tr>
                                    <td>{{ $row->getName() }}</td>
                                    <td class="td-actions text-right">
                                        @if($row->flag == 'mainpage')
                                        <li>
                                            <a rel="tooltip" href="{{ route('admin.flat.flagCancel', $row->id) }}" title="Отменить">
                                                <i class="pe-7s-flag"></i>
                                            </a>
                                        </li>
                                        @else
                                        <li>
                                            <a rel="tooltip" class="edit" href="{{ route('admin.flat.mainpage', $row->id) }}" title="Главная">
                                                <i class="pe-7s-flag"></i>
                                            </a>
                                        </li>
                                        @endif
                                        @if($row->flag == 'special')
                                        <li>
                                            <a rel="tooltip" href="{{ route('admin.flat.flagCancel', $row->id) }}" title="Отменить">
                                                <i class="pe-7s-diamond"></i>
                                            </a>
                                        </li>
                                        @else
                                        <li>
                                        <a rel="tooltip" class="delete" href="{{ route('admin.flat.special', $row->id) }}" title="Специальное">
                                            <i class="pe-7s-diamond"></i>
                                        </a>
                                        </li>
                                        @endif
                                    </td>
                                </tr>         
                                @endforeach  

                                <tr>
                                    <td class="heading">
                                        <h3>Отели</h3>
                                    </td>
                                    <td></td>
                                </tr>
                                @foreach($hotels as $row)
                                <tr>
                                    <td>{{ $row->getName() }}</td>
                                    <td class="td-actions text-right">
                                        @if($row->flag == 'mainpage')
                                        <li>
                                            <a rel="tooltip" href="{{ route('admin.hotel.flagCancel', $row->id) }}" title="Отменить">
                                                <i class="pe-7s-flag"></i>
                                            </a>
                                        </li>
                                        @else
                                        <li>
                                            <a rel="tooltip" class="edit" href="{{ route('admin.hotel.mainpage', $row->id) }}" title="Главная">
                                                <i class="pe-7s-flag"></i>
                                            </a>
                                        </li>
                                        @endif
                                        @if($row->flag == 'special')
                                        <li>
                                            <a rel="tooltip" href="{{ route('admin.hotel.flagCancel', $row->id) }}" title="Отменить">
                                                <i class="pe-7s-diamond"></i>
                                            </a>
                                        </li>
                                        @else
                                        <li>
                                        <a rel="tooltip" class="delete" href="{{ route('admin.hotel.special', $row->id) }}" title="Специальное">
                                            <i class="pe-7s-diamond"></i>
                                        </a>
                                        </li>
                                        @endif
                                    </td>
                                </tr>         
                                @endforeach 

                                <tr>
                                    <td class="heading">
                                        <h3>Особняки</h3>
                                    </td>
                                    <td></td>
                                </tr>
                                @foreach($mansions as $row)
                                <tr>
                                    <td>{{ $row->getName() }}</td>
                                    <td class="td-actions text-right">
                                        @if($row->flag == 'mainpage')
                                        <li>
                                            <a rel="tooltip" href="{{ route('admin.mansion.flagCancel', $row->id) }}" title="Отменить">
                                                <i class="pe-7s-flag"></i>
                                            </a>
                                        </li>
                                        @else
                                        <li>
                                            <a rel="tooltip" class="edit" href="{{ route('admin.mansion.mainpage', $row->id) }}" title="Главная">
                                                <i class="pe-7s-flag"></i>
                                            </a>
                                        </li>
                                        @endif
                                        @if($row->flag == 'special')
                                        <li>
                                            <a rel="tooltip" href="{{ route('admin.mansion.flagCancel', $row->id) }}" title="Отменить">
                                                <i class="pe-7s-diamond"></i>
                                            </a>
                                        </li>
                                        @else
                                        <li>
                                        <a rel="tooltip" class="delete" href="{{ route('admin.mansion.special', $row->id) }}" title="Специальное">
                                            <i class="pe-7s-diamond"></i>
                                        </a>
                                        </li>
                                        @endif
                                    </td>
                                </tr>         
                                @endforeach  

                                <tr>
                                    <td class="heading">
                                        <h3>Пансионаты</h3>
                                    </td>
                                    <td></td>
                                </tr>
                                @foreach($pensions as $row)
                                <tr>
                                    <td>{{ $row->getName() }}</td>
                                    <td class="td-actions text-right">
                                        @if($row->flag == 'mainpage')
                                        <li>
                                            <a rel="tooltip" href="{{ route('admin.pension.flagCancel', $row->id) }}" title="Отменить">
                                                <i class="pe-7s-flag"></i>
                                            </a>
                                        </li>
                                        @else
                                        <li>
                                            <a rel="tooltip" class="edit" href="{{ route('admin.pension.mainpage', $row->id) }}" title="Главная">
                                                <i class="pe-7s-flag"></i>
                                            </a>
                                        </li>
                                        @endif
                                        @if($row->flag == 'special')
                                        <li>
                                            <a rel="tooltip" href="{{ route('admin.pension.flagCancel', $row->id) }}" title="Отменить">
                                                <i class="pe-7s-diamond"></i>
                                            </a>
                                        </li>
                                        @else
                                        <li>
                                        <a rel="tooltip" class="delete" href="{{ route('admin.pension.special', $row->id) }}" title="Специальное">
                                            <i class="pe-7s-diamond"></i>
                                        </a>
                                        </li>
                                        @endif
                                    </td>
                                </tr>         
                                @endforeach  

                                </tbody>
                            </table>
                        </div>

                        <div class="footer">
                            <hr>
                            <div class="stats">
                                <i class="fa fa-history"></i> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection