@extends('Admin::layouts.default')
@section('title', $hotel->getName())

@section('content')

    @include('Admin::hotel.nav')

    <div class="content">
        <div class="container-fluid">

            <div class="row">

                <div class="col-md-12">
                    <div class="card card-info">
                        <div class="header">
                            <h4 class="title">
                                {{ $hotel->getName() }}
                            </h4>
                        </div>

                        <div class="content">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <tbody>
                                                <tr>
                                                    <td class="heading">
                                                        Название
                                                    </td>
                                                    <td>
                                                        {{ $hotel->getName() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Номера
                                                    </td>
                                                    <td>
                                                        <a href="{{ route('admin.hotel.showNumber',$hotel->id) }}" data-href="{{ route('admin.hotel.showNumber') }}">
                                                            <i class="pe-7s-keypad"></i>
                                                            <p>Номера</p>
                                                        </a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Название на Английском
                                                    </td>
                                                    <td>
                                                        {{ $hotel->getNameEn() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Название на Кыргызском
                                                    </td>
                                                    <td>
                                                        {{ $hotel->getNameKg() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Описание
                                                    </td>
                                                    <td>
                                                    <textarea disabled="" class="form-control" rows="5">{{ $hotel->getDescription() }}</textarea>
                                                        
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Описание на Английском
                                                    </td>
                                                    <td>
                                                        <textarea disabled="" class="form-control" rows="5">{{ $hotel->getDescriptionEn() }}</textarea>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Описание на Кыргызском
                                                    </td>
                                                    <td>
                                                    <textarea disabled="" class="form-control" rows="5">{{ $hotel->getDescriptionKg() }}</textarea>
                                                    </td>
                                                </tr>
                                                
                                                <tr>
                                                    <td class="heading">
                                                        Область
                                                    </td>
                                                    <td>
                                                        @if($hotel->districtRelation()->first())
                                                        {{ $hotel->districtRelation()->first()->getName() }}
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Город
                                                    </td>
                                                    <td>
                                                        @if($hotel->cityRelation()->first())
                                                        {{ $hotel->cityRelation()->first()->getName() }}
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Район
                                                    </td>
                                                    <td>
                                                        @if($hotel->regionRelation()->first())
                                                        {{ $hotel->regionRelation()->first()->getName() }}
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Улица
                                                    </td>
                                                    <td>
                                                        {{ $hotel->getStreet() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Пересекается
                                                    </td>
                                                    <td>
                                                        {{ $hotel->getCrosses() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Номер дома
                                                    </td>
                                                    <td>
                                                        {{ $hotel->getApartment() }}
                                                    </td>
                                                </tr> 
                                                <tr>
                                                    <td class="heading">
                                                        Номер квартиры
                                                    </td>
                                                    <td>
                                                        {{ $hotel->getHomenumber() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        На карте
                                                    </td>
                                                    <td>
                                                    <div class="row"> <!-- Map -->
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <div id="map_canvas" style="width:650px; margin: 20px; height:460px; border:solid 1px #FF0000" ></div>
                                                                <input name="latitude" id="latitude" type="hidden">
                                                                <input name="longitude" id="longitude" type="hidden">
                                                                <input name="zoom" id="zoom" type="hidden">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td class="heading">
                                                        Телефоны
                                                    </td>
                                                    <td>
                                                        {{ $hotel->getPhone() }} ,
                                                        {{ $hotel->getPhone2() }} ,
                                                        {{ $hotel->getPhone3() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Email
                                                    </td>
                                                    <td>
                                                        {{ $hotel->getEmail() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Skype
                                                    </td>
                                                    <td>
                                                        {{ $hotel->getSkype() }}
                                                    </td>
                                                </tr>
                                                
                                                <tr>
                                                    <td class="heading">
                                                        Главное фото
                                                    </td>
                                                    <td>
                                                        <img src="{{ asset($hotel->getAttachment()) }}" width="460">
                                                    </td>
                                                </tr>
                                                
                                            </tbody>
                                        </table>
                                    </div>


                                    
                                    <div class="actions">
                                        <a href="{{ route('admin.hotel.edit', $hotel)}}" class="btn btn-primary">
                                            Редактировать
                                        </a>
                                        <a href="#" onclick="history.go(-1);" class="btn btn-default">Назад</a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')
<script type="text/javascript"
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAkDCwNRQqDIE_kz7uBfmNl1iOBsCT2nt8&sensor=true">
    </script>
    <script type="text/javascript">
      function initialize() {
        var mapOptions = {
          zoom: {{ $hotel->getZoom()}},
          center: new google.maps.LatLng({{ $hotel->getLatitude()}},{{ $hotel->getLongitude()}}),
          mapTypeId: google.maps.MapTypeId.ROADMAP
        }
        var map = new google.maps.Map(document.getElementById('map_canvas'),mapOptions);
        geocoder = new google.maps.Geocoder();

        var image = 'images/beachflag.png';
        var myLatLng = new google.maps.LatLng({{ $hotel->getLatitude()}},{{ $hotel->getLongitude()}});
        
        
        var marker = new google.maps.Marker({
            position: myLatLng, 
            map: map, 
            title: "{{ $hotel->getStreet()}} {{ $hotel->getApartment()}}"
        });  
      }
      
    </script>
@stop