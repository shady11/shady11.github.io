@extends('Admin::layouts.default')
@section('title', "Отели")

@section('content')
@include('Admin::hotel.nav')
<div class="content">
    <div class="container-fluid">

        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">
                            Отели
                        </h4>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover">
                            <thead>
                                <th>ID</th>
                                <th>Название</th>
                                <th>Действия</th>
                            </thead>
                            <tbody>
                                @foreach($hotels as $hotel)
                                    <tr class="success">
                                        <td>{{ $hotel->getId() }}</td>
                                        <td>
                                            <a href="{{ route('admin.hotel.show', $hotel) }}">
                                                {{ $hotel->getName() }}
                                            </a>
                                        </td>

                                        <td>
                                            <ul>
                                                <li>
                                                    <a rel="tooltip" class="view" href="{{ route('admin.hotel.numberHotel', $hotel->id) }}" title="Добавить номер">
                                                        <i class="pe-7s-plus"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="view" href="{{ route('admin.hotel.showHotel', $hotel) }}" title="Посмотреть">
                                                        <i class="pe-7s-next-2"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="edit" href="{{ route('admin.hotel.edit', $hotel) }}" title="Редактировать">
                                                        <i class="pe-7s-pen"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="delete" href="{{ route('admin.hotel.softDelete', $hotel) }}" title="Удалить">
                                                        <i class="pe-7s-trash"></i>
                                                    </a>
                                                </li>
                                                @if($hotel->flag == 'mainpage')
                                                <li>
                                                    <a rel="tooltip" href="{{ route('admin.hotel.flagCancel', $hotel->id) }}" title="Отменить">
                                                        <i class="pe-7s-flag"></i>
                                                    </a>
                                                </li>
                                                @else
                                                <li>
                                                    <a rel="tooltip" class="edit" href="{{ route('admin.hotel.mainpage', $hotel->id) }}" title="Главная">
                                                        <i class="pe-7s-flag"></i>
                                                    </a>
                                                </li>
                                                @endif

                                                @if($hotel->flag == 'special')
                                                <li>
                                                    <a rel="tooltip" href="{{ route('admin.hotel.flagCancel', $hotel->id) }}" title="Отменить">
                                                        <i class="pe-7s-diamond"></i>
                                                    </a>
                                                </li>
                                                @else
                                                <li>
                                                <a rel="tooltip" class="delete" href="{{ route('admin.hotel.special', $hotel->id) }}" title="Специальное">
                                                    <i class="pe-7s-diamond"></i>
                                                </a>
                                                </li>
                                                @endif
                                            </ul>
                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection