@extends('Admin::layouts.default')
@section('title', $hotelParent->getName())

@section('content')
@include('Admin::hotel.navNumber')
<div class="content">
    <div class="container-fluid">

        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">
                            Отели
                        </h4>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover">
                            <thead>
                                <th>ID</th>
                                <th>Название</th>
                                <th>Действия</th>
                            </thead>
                            <tbody>
                                @foreach($hotelNumbers as $hotelNumber)
                                    <tr class="success">
                                        <td>{{ $hotelNumber->getId() }}</td>
                                        <td>
                                            <a href="{{ route('admin.hotel.show', $hotelNumber) }}">
                                                {{ $hotelNumber->getName() }}
                                            </a>
                                        </td>

                                        <td>
                                            <ul>
                                                <li>
                                                    <a rel="tooltip" class="view" href="{{ route('admin.hotel.showHotel', $hotelNumber) }}" title="Посмотреть">
                                                        <i class="pe-7s-next-2"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="edit" href="{{ route('admin.hotel.edit', $hotelNumber) }}" title="Редактировать">
                                                        <i class="pe-7s-pen"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="delete" href="{{ route('admin.hotel.softDelete', $hotelNumber) }}" title="Удалить">
                                                        <i class="pe-7s-trash"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection