<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label for="district_id">Области</label>
            {!! Form::select('district_id', $districts, null, ["onchange"=>"loadCities($('#district_id'), $('#city_id'))","class" => "form-control selectpicker","id"=>"district_id", "title" => "-- Выберите --"]) !!}
        </div>
    </div>

    <div class="col-md-3">
        <div class="form-group">
            <label for="cities_id">Города</label>
            <select name="city_id" class="form-control selectpicker" title="-- Выберите --" id="city_id">
            </select>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="name">Название на русском</label>
            {!! Form::text('name', null, ["class" => "form-control", "required" => true, "placeholder" => "Название на русском"]) !!}
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="nameEn">Название на английском</label>
            {!! Form::text('nameEn', null, ["class" => "form-control", "placeholder" => "Название на английском"]) !!}
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label for="nameKg">Название на кыргызском</label>
            {!! Form::text('nameKg', null, ["class" => "form-control", "placeholder" => "Название на кыргызском"]) !!}
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Описание на русском</label>
            {!! Form::textarea('description', null, ["class" => "form-control", "rows"=>5, "placeholder" => "Описание на русском"]) !!}
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label>Описание на английском</label>
{!! Form::textarea('descriptionEn', null, ["class" => "form-control", "rows"=>5, "placeholder" => "Описание на английском"]) !!}
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label>Описание на кыргызском</label>
{!! Form::textarea('descriptionEn', null, ["class" => "form-control", "rows"=>5, "placeholder" => "Описание на кыргызском"]) !!}
        </div>
    </div>
</div>

<div class="action">
    <button type="submit" class="btn btn-primary">Сохранить</button>
    <button onclick="history.go(-1);" class="btn btn-default">Назад</button>
</div>