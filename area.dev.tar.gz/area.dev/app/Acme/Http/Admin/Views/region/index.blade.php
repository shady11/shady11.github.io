@extends('Admin::layouts.default')
@section('title', "Районы")

@section('content')
@include('Admin::region.nav')
<div class="content">
    <div class="container-fluid">

        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">
                            Районы
                        </h4>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover">
                            <thead>
                                <th>ID</th>
                                <th>Название</th>
                                <th>Город</th>
                                <th>Область</th>
                                <th>Действия</th>
                            </thead>
                            <tbody>
                                @foreach($regions as $region)
                                    <tr class="success">
                                        <td>{{ $region->getId() }}</td>
                                        <td>
                                            <a href="{{ route('admin.region.show', $region) }}">
                                                {{ $region->getName() }}
                                            </a>
                                        </td>
                                        <td>
                                            {{ $region->cityRelationship()->first()->getName() }}
                                        </td>
                                        <td>
                                            {{ $region->districtRelationship()->first()->getName() }}
                                        </td>

                                        <td>
                                            <ul>
                                                <li>
                                                    <a rel="tooltip" class="view" href="{{ route('admin.region.show', $region) }}" title="Посмотреть">
                                                        <i class="pe-7s-next-2"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="edit" href="{{ route('admin.region.edit', $region) }}" title="Редактировать">
                                                        <i class="pe-7s-pen"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="delete" href="{{ route('admin.region.softDelete', $region) }}" title="Удалить">
                                                        <i class="pe-7s-trash"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection