    <!-- sidebar menu -->
    <div class="sidebar" data-color="blue" data-image="{{ asset('images/admin/img/sidebar-5.jpg') }}">
        <!--
            Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
            Tip 2: you can also add an image using data-image tag
        -->
        <div class="sidebar-wrapper">
            <div class="logo">
                <a href="#" class="simple-text">
                    GLS Admin
                </a>
            </div>

            <ul id="mainNav" class="nav">
                <li>
                    <a href="{{ route('admin.home') }}" data-href="{{ route('admin.home') }}">
                        <i class="pe-7s-graph"></i>
                        <p>Главная</p>
                    </a>
                </li>
                
                <li>
                    <a href="{{ route('admin.flat.index') }}" data-href="{{ route('admin.flat.index') }}">
                        <i class="pe-7s-keypad"></i>
                        <p>Квартиры</p>
                    </a>
                </li>
                <li>
                    <a href="{{ route('admin.hotel.index') }}" data-href="{{ route('admin.flat.index') }}">
                        <i class="pe-7s-keypad"></i>
                        <p>Отели</p>
                    </a>
                </li>

                <li>
                    <a href="{{ route('admin.pension.index') }}" data-href="{{ route('admin.pension.index') }}">
                        <i class="pe-7s-keypad"></i>
                        <p>Пансионаты</p>
                    </a>
                </li>
                <li>
                    <a href="{{ route('admin.mansion.index') }}" data-href="{{ route('admin.mansion.index') }}">
                        <i class="pe-7s-keypad"></i>
                        <p>Особняки</p>
                    </a>
                </li>
                <li>
                    <a href="{{ route('admin.region.index') }}" data-href="{{ route('admin.region.index') }}">
                        <i class="pe-7s-network"></i>
                        <p>Районы</p>
                    </a>
                </li>
                
                <li>
                    <a href="{{ route('admin.city.index') }}" data-href="{{ route('admin.city.index') }}">
                        <i class="pe-7s-note2"></i>
                        <p>Города</p>
                    </a>
                </li>
                
                <li>
                    <a href="{{ route('admin.district.index') }}" data-href="{{ route('admin.district.index') }}">
                        <i class="pe-7s-network"></i>
                        <p>Области</p>
                    </a>
                </li>

                <li>
                    <a href="{{ route('admin.inventory.index') }}" data-href="{{ route('admin.inventory.index') }}">
                        <i class="pe-7s-network"></i>
                        <p>Инвентарь</p>
                    </a>
                </li>
                
                <li>
                    <a href="{{ route('admin.user.index') }}" data-href="{{ route('admin.user.index') }}">
                        <i class="pe-7s-users"></i>
                        <p>Пользователи</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <!--  end sidebar menu -->

    <div class="main-panel">