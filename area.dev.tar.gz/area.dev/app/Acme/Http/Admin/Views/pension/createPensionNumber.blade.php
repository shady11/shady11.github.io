@extends('Admin::layouts.default')
@section('title', "Новый номер")

@section('styles')
    <meta name="_token" content="{!! csrf_token() !!}"/>
    <link rel="stylesheet" type="text/css" href="{{ asset('css/jasny-bootstrap.css') }}" />
@stop

@section('content')

    @include('Admin::pension.nav')

    <div class="content">
        <div class="container-fluid">

            <div class="row">

                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h4 class="title">Новый номер</h4>
                        </div>
                        <div class="content">
                            {!! Form::model($pension, ['route' => 'admin.pension.numberStore', 'enctype' => 'multipart/form-data']) !!}
                                @include('Admin::pension.form', [$pension])
                            {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')
    <script type="text/javascript" src="{{ asset('js/admin/moment.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/admin/transition.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/admin/collapse.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/admin/ru.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/admin/bootstrap-datetimepicker.js') }}"></script>

    <script type="text/javascript"
          src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAkDCwNRQqDIE_kz7uBfmNl1iOBsCT2nt8&sensor=true">
    </script>
    <script>
        function initialize() 
        {
            mapOptions = {
              zoom: 13,
              center: new google.maps.LatLng(42.8571633,74.5703157),
              mapTypeId: google.maps.MapTypeId.ROADMAP
            }
            map = new google.maps.Map(document.getElementById('map_canvas'),mapOptions);
            geocoder = new google.maps.Geocoder();
    
            //var image = 'images/beachflag.png';
            var myLatLng = new google.maps.LatLng(42.8571633,74.5703157);

            marker = new google.maps.Marker({
                position: myLatLng, 
                map: map, 
                title: "Ваш объект?"
            });
            
            google.maps.event.addListener(map, 'center_changed', function() {
                marker.setPosition(map.getCenter());
                document.getElementById("latitude").value = map.getCenter().lat(); 
                document.getElementById("longitude").value = map.getCenter().lng(); 
                document.getElementById("zoom").value = map.getZoom(); 
            });
            
            google.maps.event.addListener(map, "zoom_changed", function(){ 
              document.getElementById("zoom").value = map.getZoom(); 
            }); 
              
        }


        function loadCities(source, target) {
            var id = source.val();
            var dataString = 'id=' + id;
            var url = "{{ route('admin.loadCities') }}";

            $.ajaxSetup({
                headers: {'X-CSRF-Token': $('meta[name=_token]').attr('content')}
            });

            $.ajax
            ({
                type: "POST",
                url: url,
                data: dataString,
                cache: false,
                success: function (data) {
                    target.html(data);
                    $('.selectpicker').selectpicker('refresh');
                }
            });
        }  

        function loadRegions(source, target) {
            var id = source.val();
            var dataString = 'id=' + id;
            var url = "{{ route('admin.loadRegions') }}";

            $.ajaxSetup({
                headers: {'X-CSRF-Token': $('meta[name=_token]').attr('content')}
            });

            $.ajax
            ({
                type: "POST",
                url: url,
                data: dataString,
                cache: false,
                success: function (data) {
                    target.html(data);
                    $('.selectpicker').selectpicker('refresh');
                }
            });
        }  
    
    </script>
    
@stop