@extends('Admin::layouts.default')
@section('title', "Пансионат")

@section('content')
@include('Admin::pension.nav')
<div class="content">
    <div class="container-fluid">

        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">
                            Пансионаты
                        </h4>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover">
                            <thead>
                                <th>ID</th>
                                <th>Название</th>
                                <th>Действия</th>
                            </thead>
                            <tbody>
                                @foreach($pensions as $pension)
                                    <tr class="success">
                                        <td>{{ $pension->getId() }}</td>
                                        <td>
                                            <a href="{{ route('admin.pension.showPension', $pension->id) }}">
                                                {{ $pension->getName() }}
                                            </a>
                                        </td>

                                        <td>
                                            <ul>
                                                <li>
                                                    <a rel="tooltip" class="view" href="{{ route('admin.pension.createPensionNumber', $pension->id) }}" title="Добавить номер">
                                                        <i class="pe-7s-plus"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="view" href="{{ route('admin.pension.showPension', $pension) }}" title="Посмотреть">
                                                        <i class="pe-7s-next-2"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="edit" href="{{ route('admin.pension.edit', $pension) }}" title="Редактировать">
                                                        <i class="pe-7s-pen"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="delete" href="{{ route('admin.pension.softDelete', $pension) }}" title="Удалить">
                                                        <i class="pe-7s-trash"></i>
                                                    </a>
                                                </li>
                                                @if($pension->flag == 'mainpage')
                                                <li>
                                                    <a rel="tooltip" href="{{ route('admin.pension.flagCancel', $pension->id) }}" title="Отменить">
                                                        <i class="pe-7s-flag"></i>
                                                    </a>
                                                </li>
                                                @else
                                                <li>
                                                    <a rel="tooltip" class="edit" href="{{ route('admin.pension.mainpage', $pension->id) }}" title="Главная">
                                                        <i class="pe-7s-flag"></i>
                                                    </a>
                                                </li>
                                                @endif

                                                @if($pension->flag == 'special')
                                                <li>
                                                    <a rel="tooltip" href="{{ route('admin.pension.flagCancel', $pension->id) }}" title="Отменить">
                                                        <i class="pe-7s-diamond"></i>
                                                    </a>
                                                </li>
                                                @else
                                                <li>
                                                <a rel="tooltip" class="delete" href="{{ route('admin.pension.special', $pension->id) }}" title="Специальное">
                                                    <i class="pe-7s-diamond"></i>
                                                </a>
                                                </li>
                                                @endif


                                            </ul>
                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection