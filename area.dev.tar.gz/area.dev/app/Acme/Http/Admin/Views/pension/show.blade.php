@extends('Admin::layouts.default')
@section('title', $pension->getName())

@section('content')

    @include('Admin::pension.nav')

    <div class="content">
        <div class="container-fluid">

            <div class="row">

                <div class="col-md-12">
                    <div class="card card-info">
                        <div class="header">
                            <h4 class="title">
                                {{ $pension->getName() }}
                            </h4>
                        </div>

                        <div class="content">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <tbody>
                                                <tr>
                                                    <td class="heading">
                                                        Название
                                                    </td>
                                                    <td>
                                                        {{ $pension->getName() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Название на Английском
                                                    </td>
                                                    <td>
                                                        {{ $pension->getNameEn() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Название на Кыргызском
                                                    </td>
                                                    <td>
                                                        {{ $pension->getNameKg() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Описание
                                                    </td>
                                                    <td>
                                                    <textarea disabled="" class="form-control" rows="5">{{ $pension->getDescription() }}</textarea>
                                                        
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Описание на Английском
                                                    </td>
                                                    <td>
                                                        <textarea disabled="" class="form-control" rows="5">{{ $pension->getDescriptionEn() }}</textarea>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Описание на Кыргызском
                                                    </td>
                                                    <td>
                                                    <textarea disabled="" class="form-control" rows="5">{{ $pension->getDescriptionKg() }}</textarea>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Цена за час
                                                    </td>
                                                    <td>
                                                        {{ $pension->getPriceHourKg() }}
                                                        {{ $pension->getPriceHourRu() }}
                                                        {{ $pension->getPriceHourEn() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Цена за ночь
                                                    </td>
                                                    <td>
                                                        {{ $pension->getPriceNightKg() }}
                                                        {{ $pension->getPriceNightRu() }}
                                                        {{ $pension->getPriceNightEn() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Цена за Сутки
                                                    </td>
                                                    <td>
                                                        {{ $pension->getPrice24Kg() }}
                                                        {{ $pension->getPrice24Ru() }}
                                                        {{ $pension->getPrice24En() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Цена за Месяц
                                                    </td>
                                                    <td>
                                                        {{ $pension->getPriceMonthKg() }}
                                                        {{ $pension->getPriceMonthRu() }}
                                                        {{ $pension->getPriceMonthEn() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Область
                                                    </td>
                                                    <td>
                                                        @if($pension->districtRelation()->first())
                                                        {{ $pension->districtRelation()->first()->getName() }}
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Город
                                                    </td>
                                                    <td>
                                                        @if($pension->cityRelation()->first())
                                                        {{ $pension->cityRelation()->first()->getName() }}
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Район
                                                    </td>
                                                    <td>
                                                        @if($pension->regionRelation()->first())
                                                        {{ $pension->regionRelation()->first()->getName() }}
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Улица
                                                    </td>
                                                    <td>
                                                        {{ $pension->getStreet() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Пересекается
                                                    </td>
                                                    <td>
                                                        {{ $pension->getCrosses() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Номер дома
                                                    </td>
                                                    <td>
                                                        {{ $pension->getApartment() }}
                                                    </td>
                                                </tr> 
                                                <tr>
                                                    <td class="heading">
                                                        Номер квартиры
                                                    </td>
                                                    <td>
                                                        {{ $pension->getHomenumber() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        На карте
                                                    </td>
                                                    <td>
                                                    <div class="row"> <!-- Map -->
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <div id="map_canvas" style="width:650px; margin: 20px; height:460px; border:solid 1px #FF0000" ></div>
                                                                <input name="latitude" id="latitude" type="hidden">
                                                                <input name="longitude" id="longitude" type="hidden">
                                                                <input name="zoom" id="zoom" type="hidden">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td class="heading">
                                                        Телефоны
                                                    </td>
                                                    <td>
                                                        {{ $pension->getPhone() }} ,
                                                        {{ $pension->getPhone2() }} ,
                                                        {{ $pension->getPhone3() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Email
                                                    </td>
                                                    <td>
                                                        {{ $pension->getEmail() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Skype
                                                    </td>
                                                    <td>
                                                        {{ $pension->getSkype() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Количество комнат
                                                    </td>
                                                    <td>
                                                        {{ $pension->getRoom() }}
                                                    </td>
                                                </tr>
                                                 <tr>
                                                    <td class="heading">
                                                        Количество спальных мест
                                                    </td>
                                                    <td>
                                                        {{ $pension->getBed() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Этажность
                                                    </td>
                                                    <td>
                                                        {{ $pension->getFloor() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Площадь
                                                    </td>
                                                    <td>
                                                        {{ $pension->getMsquare() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Wifi
                                                    </td>
                                                    <td>
                                                        {{ $pension->getWifi() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Главное фото
                                                    </td>
                                                    <td>
                                                        <img src="{{ asset($pension->getAttachment()) }}" width="460">
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td class="heading">
                                                        Все картинки
                                                    </td>
                                                    <td>
                                                        @foreach($pensionPhotos as $row)
                                                            <img src="{{ asset($row->getFile()) }}" width="250">
                                                        @endforeach
                                                    </td>
                                                </tr>
                                                
                                            </tbody>
                                        </table>
                                    </div>


                                    
                                    <div class="actions">
                                        <a href="{{ route('admin.pension.edit', $pension)}}" class="btn btn-primary">
                                            Редактировать
                                        </a>
                                        <a href="#" onclick="history.go(-1);" class="btn btn-default">Назад</a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')
<script type="text/javascript"
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAkDCwNRQqDIE_kz7uBfmNl1iOBsCT2nt8&sensor=true">
    </script>
    <script type="text/javascript">
      function initialize() {
        var mapOptions = {
          zoom: {{ $pension->getZoom()}},
          center: new google.maps.LatLng({{ $pension->getLatitude()}},{{ $pension->getLongitude()}}),
          mapTypeId: google.maps.MapTypeId.ROADMAP
        }
        var map = new google.maps.Map(document.getElementById('map_canvas'),mapOptions);
        geocoder = new google.maps.Geocoder();

        var image = 'images/beachflag.png';
        var myLatLng = new google.maps.LatLng({{ $pension->getLatitude()}},{{ $pension->getLongitude()}});
        
        
        var marker = new google.maps.Marker({
            position: myLatLng, 
            map: map, 
            title: "{{ $pension->getStreet()}} {{ $pension->getApartment()}}"
        });  
      }
      
    </script>
@stop