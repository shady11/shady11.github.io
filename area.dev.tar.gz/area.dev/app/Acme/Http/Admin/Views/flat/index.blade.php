@extends('Admin::layouts.default')
@section('title', "Объекты")

@section('content')
@include('Admin::flat.nav')
<div class="content">
    <div class="container-fluid">

        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">
                            Объекты
                        </h4>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover">
                            <thead>
                                <th>ID</th>
                                <th>Название</th>
                                <th>Действия</th>
                            </thead>
                            <tbody>
                                @foreach($flats as $flat)
                                    <tr class="success">
                                        <td>{{ $flat->getId() }}</td>
                                        <td>
                                            <a href="{{ route('admin.flat.show', $flat) }}">
                                                {{ $flat->getName() }}
                                            </a>
                                        </td>

                                        <td>
                                            <ul>
                                                <li>
                                                    <a rel="tooltip" class="view" href="{{ route('admin.flat.show', $flat) }}" title="Посмотреть">
                                                        <i class="pe-7s-next-2"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="edit" href="{{ route('admin.flat.edit', $flat) }}" title="Редактировать">
                                                        <i class="pe-7s-pen"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="delete" href="{{ route('admin.flat.softDelete', $flat) }}" title="Удалить">
                                                        <i class="pe-7s-trash"></i>
                                                    </a>
                                                </li> 
                                                @if($flat->flag == 'mainpage')
                                                <li>
                                                    <a rel="tooltip" href="{{ route('admin.flat.flagCancel', $flat->id) }}" title="Отменить">
                                                        <i class="pe-7s-flag"></i>
                                                    </a>
                                                </li>
                                                @else
                                                <li>
                                                    <a rel="tooltip" class="edit" href="{{ route('admin.flat.mainpage', $flat->id) }}" title="Главная">
                                                        <i class="pe-7s-flag"></i>
                                                    </a>
                                                </li>
                                                @endif

                                                @if($flat->flag == 'special')
                                                <li>
                                                    <a rel="tooltip" href="{{ route('admin.flat.flagCancel', $flat->id) }}" title="Отменить">
                                                        <i class="pe-7s-diamond"></i>
                                                    </a>
                                                </li>
                                                @else
                                                <li>
                                                <a rel="tooltip" class="delete" href="{{ route('admin.flat.special', $flat->id) }}" title="Специальное">
                                                    <i class="pe-7s-diamond"></i>
                                                </a>
                                                </li>
                                                @endif
                                                
                                            </ul>
                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection