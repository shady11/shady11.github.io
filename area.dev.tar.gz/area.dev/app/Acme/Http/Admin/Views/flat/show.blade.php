@extends('Admin::layouts.default')
@section('title', $flat->getName())

@section('content')

    @include('Admin::flat.nav')

    <div class="content">
        <div class="container-fluid">

            <div class="row">

                <div class="col-md-12">
                    <div class="card card-info">
                        <div class="header">
                            <h4 class="title">
                                {{ $flat->getName() }}
                            </h4>
                        </div>

                        <div class="content">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <tbody>
                                                <tr>
                                                    <td class="heading">
                                                        Название
                                                    </td>
                                                    <td>
                                                        {{ $flat->getName() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Название на Английском
                                                    </td>
                                                    <td>
                                                        {{ $flat->getNameEn() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Название на Кыргызском
                                                    </td>
                                                    <td>
                                                        {{ $flat->getNameKg() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Описание
                                                    </td>
                                                    <td>
                                                    <textarea disabled="" class="form-control" rows="5">{{ $flat->getDescription() }}</textarea>
                                                        
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Описание на Английском
                                                    </td>
                                                    <td>
                                                        <textarea disabled="" class="form-control" rows="5">{{ $flat->getDescriptionEn() }}</textarea>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Описание на Кыргызском
                                                    </td>
                                                    <td>
                                                    <textarea disabled="" class="form-control" rows="5">{{ $flat->getDescriptionKg() }}</textarea>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Цена за час
                                                    </td>
                                                    <td>
                                                        {{ $flat->getPriceHourKg() }}
                                                        {{ $flat->getPriceHourRu() }}
                                                        {{ $flat->getPriceHourEn() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Цена за ночь
                                                    </td>
                                                    <td>
                                                        {{ $flat->getPriceNightKg() }}
                                                        {{ $flat->getPriceNightRu() }}
                                                        {{ $flat->getPriceNightEn() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Цена за Сутки
                                                    </td>
                                                    <td>
                                                        {{ $flat->getPrice24Kg() }}
                                                        {{ $flat->getPrice24Ru() }}
                                                        {{ $flat->getPrice24En() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Цена за Месяц
                                                    </td>
                                                    <td>
                                                        {{ $flat->getPriceMonthKg() }}
                                                        {{ $flat->getPriceMonthRu() }}
                                                        {{ $flat->getPriceMonthEn() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Область
                                                    </td>
                                                    <td>
                                                        @if($flat->districtRelation()->first())
                                                        {{ $flat->districtRelation()->first()->getName() }}
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Город
                                                    </td>
                                                    <td>
                                                        @if($flat->cityRelation()->first())
                                                        {{ $flat->cityRelation()->first()->getName() }}
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Район
                                                    </td>
                                                    <td>
                                                        @if($flat->regionRelation()->first())
                                                        {{ $flat->regionRelation()->first()->getName() }}
                                                        @endif
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Улица
                                                    </td>
                                                    <td>
                                                        {{ $flat->getStreet() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Пересекается
                                                    </td>
                                                    <td>
                                                        {{ $flat->getCrosses() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Номер дома
                                                    </td>
                                                    <td>
                                                        {{ $flat->getApartment() }}
                                                    </td>
                                                </tr> 
                                                <tr>
                                                    <td class="heading">
                                                        Номер квартиры
                                                    </td>
                                                    <td>
                                                        {{ $flat->getHomenumber() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        На карте
                                                    </td>
                                                    <td>
                                                    <div class="row"> <!-- Map -->
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <div id="map_canvas" style="width:650px; margin: 20px; height:460px; border:solid 1px #FF0000" ></div>
                                                                <input name="latitude" id="latitude" type="hidden">
                                                                <input name="longitude" id="longitude" type="hidden">
                                                                <input name="zoom" id="zoom" type="hidden">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td class="heading">
                                                        Телефоны
                                                    </td>
                                                    <td>
                                                        {{ $flat->getPhone() }} ,
                                                        {{ $flat->getPhone2() }} ,
                                                        {{ $flat->getPhone3() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Email
                                                    </td>
                                                    <td>
                                                        {{ $flat->getEmail() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Skype
                                                    </td>
                                                    <td>
                                                        {{ $flat->getSkype() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Количество комнат
                                                    </td>
                                                    <td>
                                                        {{ $flat->getRoom() }}
                                                    </td>
                                                </tr>
                                                 <tr>
                                                    <td class="heading">
                                                        Количество спальных мест
                                                    </td>
                                                    <td>
                                                        {{ $flat->getBed() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Этажность
                                                    </td>
                                                    <td>
                                                        {{ $flat->getFloor() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Площадь
                                                    </td>
                                                    <td>
                                                        {{ $flat->getMsquare() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Wifi
                                                    </td>
                                                    <td>
                                                        {{ $flat->getWifi() }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="heading">
                                                        Главное фото
                                                    </td>
                                                    <td>
                                                        <img src="{{ asset($flat->getAttachment()) }}" width="460">
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td class="heading">
                                                        Все картинки
                                                    </td>
                                                    <td>
                                                        @foreach($flatPhotos as $row)
                                                            <img src="{{ asset($row->getFile()) }}" width="250">
                                                        @endforeach
                                                    </td>
                                                </tr>
                                                
                                            </tbody>
                                        </table>
                                    </div>


                                    
                                    <div class="actions">
                                        <a href="{{ route('admin.flat.edit', $flat)}}" class="btn btn-primary">
                                            Редактировать
                                        </a>
                                        <a href="#" onclick="history.go(-1);" class="btn btn-default">Назад</a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')
<script type="text/javascript"
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAkDCwNRQqDIE_kz7uBfmNl1iOBsCT2nt8&sensor=true">
    </script>
    <script type="text/javascript">
      function initialize() {
        var mapOptions = {
          zoom: {{ $flat->getZoom()}},
          center: new google.maps.LatLng({{ $flat->getLatitude()}},{{ $flat->getLongitude()}}),
          mapTypeId: google.maps.MapTypeId.ROADMAP
        }
        var map = new google.maps.Map(document.getElementById('map_canvas'),mapOptions);
        geocoder = new google.maps.Geocoder();

        var image = 'images/beachflag.png';
        var myLatLng = new google.maps.LatLng({{ $flat->getLatitude()}},{{ $flat->getLongitude()}});
        
        
        var marker = new google.maps.Marker({
            position: myLatLng, 
            map: map, 
            title: "{{ $flat->getStreet()}} {{ $flat->getApartment()}}"
        });  
      }
      
    </script>
@stop