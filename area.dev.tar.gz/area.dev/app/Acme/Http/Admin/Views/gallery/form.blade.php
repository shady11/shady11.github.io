<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="name">Выберите объект</label>
            {!! Form::select('flat_id', $flats, null, ["class" => "form-control selectpicker", "title" => "-- Выберите --"]) !!}
        </div>
    </div>
</div>


<div class="action">
    <button type="submit" class="btn btn-primary">Сохранить</button>
    <button onclick="history.go(-1);" class="btn btn-default">Назад</button>
</div>