@extends('Admin::layouts.default')
@section('title', "Галерея")

@section('content')
@include('Admin::gallery.nav')
<div class="content">
    <div class="container-fluid">

        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">
                            Галерея
                        </h4>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover">
                            <thead>
                                <th>ID</th>
                                <th>Flat id</th>
                                <th>Действия</th>
                            </thead>
                            <tbody>
                                @foreach($galleries as $gallery)
                                    <tr class="success">
                                        <td>{{ $gallery->getId() }}</td>
                                        <td>
                                            <a href="{{ route('admin.gallery.show', $gallery) }}">
                                                {{ $gallery->flat_id }}
                                            </a>
                                        </td>


                                        <td>
                                            <ul>
                                                <li>
                                                    <a rel="tooltip" class="view" href="{{ route('admin.gallery.show', $gallery) }}" title="Посмотреть">
                                                        <i class="pe-7s-next-2"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="edit" href="{{ route('admin.gallery.edit', $gallery) }}" title="Редактировать">
                                                        <i class="pe-7s-pen"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="delete" href="{{ route('admin.gallery.softDelete', $gallery) }}" title="Удалить">
                                                        <i class="pe-7s-trash"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection