@include('Admin::partials.header')

@include('Admin::partials.nav')

@yield('content')

@include('Admin::partials.footer')