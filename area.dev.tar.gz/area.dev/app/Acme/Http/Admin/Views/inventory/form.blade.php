<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="name">Название на русском</label>
            {!! Form::text('name', null, ["class" => "form-control", "required" => true, "placeholder" => "Название на русском"]) !!}
        </div>
    </div>
</div>

<!-- <div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="nameEn">Название на английском</label>
            {!! Form::text('nameEn', null, ["class" => "form-control", "placeholder" => "Название на английском"]) !!}
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label for="nameKg">Название на кыргызском</label>
            {!! Form::text('nameKg', null, ["class" => "form-control", "placeholder" => "Название на кыргызском"]) !!}
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Описание на русском</label>
            {!! Form::textarea('description', null, ["class" => "form-control", "rows"=>5, "placeholder" => "Описание на русском"]) !!}
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label>Описание на английском</label>
{!! Form::textarea('descriptionEn', null, ["class" => "form-control", "rows"=>5, "placeholder" => "Описание на английском"]) !!}
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label>Описание на кыргызском</label>
{!! Form::textarea('descriptionEn', null, ["class" => "form-control", "rows"=>5, "placeholder" => "Описание на кыргызском"]) !!}
        </div>
    </div>
</div> -->

<div class="row">
    <div class="form-group col-md-6">
        <label for="attachment">Добавить фото</label>
        <div class="fileinput fileinput-new input-group" data-provides="fileinput">
            <div class="form-control" data-trigger="fileinput">
                <i class="glyphicon glyphicon-file fileinput-exists"></i>
                <span class="fileinput-filename"></span>
            </div>
        <span class="input-group-addon btn btn-default btn-file">
                    <span class="fileinput-new">Выберите файл</span>
        <span class="fileinput-exists">Изменить</span>
        <input id="attachment" type="file" name="attachment">
        </span>
            <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Удалить</a>
        </div>
        <p class="help-block">Фото помогает исполнителям лучше понять ваше задание и оценить объем работы</p>
    </div>
</div>

<div class="action">
    <button type="submit" class="btn btn-primary">Сохранить</button>
    <button onclick="history.go(-1);" class="btn btn-default">Назад</button>
</div>