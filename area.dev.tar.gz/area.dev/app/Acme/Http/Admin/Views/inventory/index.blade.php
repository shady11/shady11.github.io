@extends('Admin::layouts.default')
@section('title', "Инвентарь")

@section('content')
@include('Admin::inventory.nav')
<div class="content">
    <div class="container-fluid">

        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">
                            Области
                        </h4>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover">
                            <thead>
                                <th>ID</th>
                                <th>Название</th>
                                <th>Изображение</th>
                                <th>Действия</th>
                            </thead>
                            <tbody>
                                @foreach($inventories as $inventory)
                                    <tr class="success">
                                        <td>{{ $inventory->getId() }}</td>
                                        <td>
                                            <a href="{{ route('admin.inventory.show', $inventory) }}">
                                                {{ $inventory->getName() }}
                                            </a>
                                        </td>
                                        <td>
                                            <img width="30px" src="{{ asset($inventory->getFile()) }}">
                                        </td>

                                        <td>
                                            <ul>
                                                <li>
                                                    <a rel="tooltip" class="view" href="{{ route('admin.inventory.show', $inventory) }}" title="Посмотреть">
                                                        <i class="pe-7s-next-2"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="edit" href="{{ route('admin.inventory.edit', $inventory) }}" title="Редактировать">
                                                        <i class="pe-7s-pen"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a rel="tooltip" class="delete" href="{{ route('admin.inventory.softDelete', $inventory) }}" title="Удалить">
                                                        <i class="pe-7s-trash"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection