<?php

Route::group(['prefix' => 'api', 'namespace' => 'Api\Controllers'], function(){
});
