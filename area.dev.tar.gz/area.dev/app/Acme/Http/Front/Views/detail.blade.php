@extends('Front::layouts.default')

@section('styles')
    <link rel="stylesheet" href="{{ asset('front/slick/slick.css') }}"/>
    <link rel="stylesheet" href="{{ asset('front/slick/slick-theme.css') }}"/>
    <script type="text/javascript" src="{{ asset('front/js/modernizr.min.js') }}"></script>
@stop

@section('content')
<section class="section-item">
    <div class="container">
        <div class="row">
            <ol class="breadcrumb">
                <li><a href="{{ route('front.home')}}">Главная</a></li>
                <li><a href="#">Квартиры</a></li>
                <li class="active">1-комнатная квартира на Ибраимова 63</li>
            </ol>
            <h2>
                <span>1-комнатная квартира на Ибраимова 63</span>
            </h2>

            <div class="panel">
                <div class="panel-body">
                    <div class="col-md-6">
                        <div class="row">
                            <div class="photos">
                                <div class="slider-for">
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                </div>
                                <div class="slider-nav">
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                    <div>
                                        <img src="{{ asset('front/images/item.jpg') }}" alt=""/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@stop

@section('footer')
<script type="text/javascript" src="{{ asset('front/js/jquery-migrate-1.2.1.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('front/slick/slick.min.js') }}"></script>

<script>
    $(document).ready(function () {
        $('.slider-for').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            fade: true,
            asNavFor: '.slider-nav',
            arrows: false
        });
        $('.slider-nav').slick({
            slidesToShow: 4,
            slidesToScroll: 1,
            asNavFor: '.slider-for',
            centerMode: true,
            focusOnSelect: true,
            variableWidth: true
        });
    });
</script>
@stop