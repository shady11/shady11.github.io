<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Area.kg</title>

    <link rel="stylesheet" href="{{ asset('front/css/bootstrap.css') }}"/>
    <link rel="stylesheet" href="{{ asset('front/css/font-awesome.css') }}"/>
    <link rel="stylesheet" href="{{ asset('front/css/pe-icon-7-stroke.css') }}"/>
    <link rel="stylesheet" href="{{ asset('front/css/bootstrap-select.css') }}"/>
    <link rel="stylesheet" href="{{ asset('front/css/bootstrap-datetimepicker.css') }}"/>
    <link rel="stylesheet" href="{{ asset('front/css/build.css') }}"/>
    <link rel="stylesheet" href="{{ asset('front/css/style.css') }}"/>

@yield('styles')
</head>
<body>
