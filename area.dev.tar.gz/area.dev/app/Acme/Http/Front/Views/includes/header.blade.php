<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Area.kg</title>

    <link rel="stylesheet" href="front/css/bootstrap.css"/>
    <link rel="stylesheet" href="front/css/font-awesome.css"/>
    <link rel="stylesheet" href="front/css/pe-icon-7-stroke.css"/>
    <link rel="stylesheet" href="front/css/bootstrap-select.css"/>
    <link rel="stylesheet" href="front/css/bootstrap-datetimepicker.css"/>
    <link rel="stylesheet" href="front/css/build.css"/>
    <link rel="stylesheet" href="front/css/style.css"/>

</head>
<body>
