@include('Front::partials.header')

@include('Front::partials.nav')

@yield('content')

@include('Front::partials.footer')
