<?php
namespace Front\Controllers;
use Illuminate\Http\Request;
use Input;
use \Model\Flat\ModelName as Flat;
use \Model\Hotel\ModelName as Hotel;
use \Model\Pension\ModelName as Pension;


class HomeController extends Controller
{
    public function __construct(){}
    public function Home()
    {
    $specialFlats = Flat::where('status','<>','deleted')->where('flatType','=','flat')->having('flag','=','special')->orderBy('id','desc')->take(1)->get();
    $specialHotel = Hotel::where('status','<>','deleted')->where('flatType','=','hotel')->where('parent','=',null)->having('flag','=','special')->orderBy('id','desc')->take(1)->first();
    $hotels = Hotel::where('parent','=',$specialHotel->id)->get();
    $hotelsCount = count($hotels);
    $specialHotelPrices = array();
    foreach($hotels as $row)
    {
        $specialHotelPrices[] = $row->priceNightKg;
    }

    $specialMansions = Flat::where('status','<>','deleted')->where('flatType','=','mansion')->having('flag','=','special')->orderBy('id','desc')->take(1)->get();


    $specialPension = Pension::where('status','<>','deleted')->where('parent','=',null)->where('flatType','=','pension')->having('flag','=','special')->orderBy('id','desc')->take(1)->first();

    $pensions = Pension::where('parent','=',$specialPension->id)->get();
    $pensionsCount = count($pensions);
    $specialPensionPrices = array();
    foreach($pensions as $row)
    {
        $specialPensionPrices[] = $row->priceNightKg;
    }

        return view('Front::home', [
            'specialFlats'=> $specialFlats,

            'specialHotel'=> $specialHotel,
            'specialHotelPrices'=> $specialHotelPrices,
            'hotelsCount' => $hotelsCount,
            'i' => $i = 0,

            'specialPension'=> $specialPension,
            'specialPensionPrices'=> $specialPensionPrices,
            'pensionsCount' => $pensionsCount,
            
            'specialMansions'=> $specialMansions,
        ]);
    }
    public function Detail()
    {
    	return view('Front::detail',[

    		]);
    }
}

