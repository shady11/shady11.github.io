<?php
namespace Model\Flat;

trait ModelHelpers
{
}