<?php
namespace Model\User;

trait ModelRelationships
{
}
