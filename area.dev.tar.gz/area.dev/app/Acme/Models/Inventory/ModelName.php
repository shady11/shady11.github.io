<?php
namespace Model\Inventory;
use Illuminate\Database\Eloquent\Model;

class ModelName extends Model
{
    use ModelHelpers, ModelRelationships;

    protected $table = 'inventory';

    protected $guarded = ['id'];

    public function getId()
    {
        return $this->id;
    }
    public function getName()
    {
        return $this->name;
    }
    public function getFile()
    {
        return $this->attachment;
    }
    public function getStatus()
    {
        return $this->status;
    }

}
