<?php
namespace Model\Inventory;

trait ModelHelpers
{
}