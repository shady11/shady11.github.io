<?php
namespace Model\Menu;

trait ModelHelpers
{

}
