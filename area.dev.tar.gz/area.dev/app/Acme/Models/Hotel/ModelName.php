<?php
namespace Model\Hotel;
use Illuminate\Database\Eloquent\Model;

class ModelName extends Model
{
    use ModelHelpers, ModelRelationships;
    protected $table = 'flats';
    protected $guarded = ['id'];

    public function getId() { return $this->id; }
    
    public function getName() { return $this->name; }
    public function getNameEn() { return $this->nameEn; }
    public function getNameKg() { return $this->nameKg; }

    public function getDescription() { return $this->description; }
    public function getDescriptionEn() { return $this->descriptionEn; }
    public function getDescriptionKg() { return $this->descriptionKg; }

    // Prices
    public function getPriceHourKg() { return $this->priceHourKg; }
    public function getPriceHourRu() { return $this->priceHourRu; }
    public function getPriceHourEn() { return $this->priceHourEn; }

    public function getPriceNightKg() { return $this->priceNightKg; }
    public function getPriceNightRu() { return $this->priceNightRu; }
    public function getPriceNightEn() { return $this->priceNightEn; }

    public function getPrice24Kg() { return $this->price24Kg; }
    public function getPrice24Ru() { return $this->price24Ru; }
    public function getPrice24En() { return $this->price24En; }

    public function getPriceMonthKg() { return $this->priceMonthKg; }
    public function getPriceMonthRu() { return $this->priceMonthRu; }
    public function getPriceMonthEn() { return $this->priceMonthEn; }

    // Street
    public function getStreet() { return $this->street; }
    public function getCrosses() { return $this->crosses; }
    public function getApartment() { return $this->apartment; }
    public function getHomenumber() { return $this->homenumber; }
    // Google Map
    public function getZoom() { return $this->zoom; }
    public function getLatitude() { return $this->latitude; }
    public function getLongitude() { return $this->longitude; }

    // Phones
    public function getPhone() { return $this->phone; }    
    public function getPhone2() { return $this->phone2; }    
    public function getPhone3() { return $this->phone3; }    
    
    
    public function getEmail() { return $this->email; }
    public function getSkype() { return $this->skype; }
    public function getRoom() { return $this->room; }
    public function getBed() { return $this->bed; }
    public function getFloor() { return $this->floor; }
    public function getMsquare() { return $this->msquare; }
    public function getWifi() { if($this->wifi == 1) {return "Да"; }else return "Нет"; }

    public function getFlatType() { return $this->flatType; }

    public function getAttachment() { return $this->attachment; }

    

}
