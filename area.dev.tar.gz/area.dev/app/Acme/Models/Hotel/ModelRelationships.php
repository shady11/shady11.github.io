<?php
namespace Model\Hotel;

trait ModelRelationships
{
    public function districtRelation(){ return $this->belongsTo(\Model\District\ModelName::class, 'district_id'); }
    public function cityRelation(){ return $this->belongsTo(\Model\City\ModelName::class, 'city_id'); }
    public function regionRelation(){ return $this->belongsTo(\Model\Region\ModelName::class, 'region_id'); }

    public function hotelNumberRelation(){ return $this->belongsTo(\Model\Hotel\ModelName::class, 'parent_id'); }
    
    public function hotelHasMany(){ 
    	return $this->hasMany(\Model\Hotel\ModelName::class, 'parent_id'); 
    }
    
}
