<?php
namespace Model\Hotel;

trait ModelHelpers
{
}