<?php
namespace Model\Gallery;
use Illuminate\Database\Eloquent\Model;

class ModelName extends Model
{
    use ModelHelpers, ModelRelationships;

    protected $table = 'gallery';

    protected $guarded = ['id'];

    public function getId()
    {
        return $this->id;
    }
    public function getFlatId()
    {
        return $this->flat_id;
    }

}
