<?php
namespace Model\Gallery;

trait ModelHelpers
{
}