<?php
namespace Model\City;

trait ModelHelpers
{
}