<?php
namespace Model\City;

trait ModelRelationships
{
    public function getDistrict(){
        return $this->belongsTo(\Model\District\ModelName::class, 'district_id');
    }
}
