<?php
namespace Model\City;
use Illuminate\Database\Eloquent\Model;

class ModelName extends Model
{
    use ModelHelpers, ModelRelationships;

    protected $table = 'cities';

    protected $guarded = ['id'];

    public function getId()
    {
        return $this->id;
    }
    public function getName()
    {
        return $this->name;
    }
    public function getNameEn()
    {
        return $this->nameEn;
    }
    public function getNameKg()
    {
        return $this->nameKg;
    }
    public function getDescription()
    {
        return $this->description;
    }
    public function getDescriptionEn()
    {
        return $this->descriptionEn;
    }
    public function getDescriptionKg()
    {
        return $this->descriptionKg;
    }
    public function getStatus()
    {
        return $this->status;
    }

}
