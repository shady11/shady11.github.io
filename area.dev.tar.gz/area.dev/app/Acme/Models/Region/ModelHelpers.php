<?php
namespace Model\Region;

trait ModelHelpers
{
}