<?php
namespace Model\Region;

trait ModelRelationships
{
    public function districtRelationship(){
        return $this->belongsTo(\Model\District\ModelName::class, 'district_id');
    }

    public function cityRelationship(){
        return $this->belongsTo(\Model\City\ModelName::class, 'city_id');
    }
}
