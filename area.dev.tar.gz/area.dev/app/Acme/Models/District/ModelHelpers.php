<?php
namespace Model\District;

trait ModelHelpers
{
}