<?php
namespace Model\Photos;

trait ModelHelpers
{
}