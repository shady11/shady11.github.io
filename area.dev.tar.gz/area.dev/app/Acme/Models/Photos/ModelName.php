<?php
namespace Model\Photos;
use Illuminate\Database\Eloquent\Model;

class ModelName extends Model
{
    use ModelHelpers, ModelRelationships;
    protected $table = 'photos';
    protected $guarded = ['id'];

    public function getId(){ return $this->id; }
    public function getFlatId(){ return $this->flat_id; }
    public function getGalleryId(){ return $this->gallery_id; }
    public function getFile(){ return $this->attachment; }

}
