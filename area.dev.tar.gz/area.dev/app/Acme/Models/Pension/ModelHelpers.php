<?php
namespace Model\Pension;

trait ModelHelpers
{
}