<?php
namespace Model\Mansion;

trait ModelHelpers
{
}