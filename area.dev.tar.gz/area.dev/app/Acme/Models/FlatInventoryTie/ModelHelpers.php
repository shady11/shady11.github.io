<?php
namespace Model\FlatInventoryTie;

trait ModelHelpers
{
}