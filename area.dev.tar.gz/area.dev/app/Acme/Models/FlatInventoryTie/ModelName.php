<?php
namespace Model\FlatInventoryTie;
use Illuminate\Database\Eloquent\Model;

class ModelName extends Model
{
    use ModelHelpers, ModelRelationships;

    protected $table = 'flat_inventory_tie';

    protected $guarded = ['id'];

    public function getId()
    {
        return $this->id;
    }
    
    public function getFlatId()
    {
        return $this->flat_id;
    }
    public function getInventoryId()
    {
        return $this->inventory_id;
    }

}
